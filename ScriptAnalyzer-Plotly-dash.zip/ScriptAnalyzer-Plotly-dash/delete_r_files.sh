#!/bin/bash

# Delete R files that are no longer needed
echo "Deleting R files that are no longer needed..."

# List of R files to delete
files=(
  "run.R" 
  "install_packages.R" 
  "simplified_stock_analysis.R"
)

# Delete each file if it exists
for file in "${files[@]}"; do
  if [ -f "$file" ]; then
    echo "Deleting $file..."
    rm "$file"
  else
    echo "$file does not exist, skipping."
  fi
done

echo "R file cleanup complete!"