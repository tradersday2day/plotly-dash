document.addEventListener('DOMContentLoaded', function() {
    // Initialize code highlighting
    document.querySelectorAll('pre code').forEach((block) => {
        hljs.highlightBlock(block);
    });

    // Make the sidebar sticky on scroll
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
        const sidebarTop = sidebar.offsetTop;
        
        window.addEventListener('scroll', function() {
            if (window.scrollY >= sidebarTop) {
                sidebar.classList.add('sticky-top');
                sidebar.style.top = '20px';
            } else {
                sidebar.classList.remove('sticky-top');
                sidebar.style.top = 'auto';
            }
        });
    }

    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 20,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Add active class to current section in sidebar
    const sections = document.querySelectorAll('div[id]');
    const navLinks = document.querySelectorAll('.nav-link');
    
    function setActiveLink() {
        let currentSection = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            const sectionHeight = section.clientHeight;
            
            if (pageYOffset >= sectionTop) {
                currentSection = '#' + section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === currentSection) {
                link.classList.add('active');
            }
        });
    }
    
    window.addEventListener('scroll', setActiveLink);

    // Additional visualization functionality - code structure collapsible sections
    const codeBlocks = document.querySelectorAll('.code-block');
    
    codeBlocks.forEach(block => {
        const codeContent = block.querySelector('pre');
        const codeHeight = codeContent.offsetHeight;
        
        // If code is long, make it collapsible
        if (codeHeight > 200) {
            codeContent.style.maxHeight = '200px';
            codeContent.style.overflow = 'hidden';
            codeContent.style.transition = 'max-height 0.3s ease-in-out';
            
            const toggleButton = document.createElement('button');
            toggleButton.classList.add('btn', 'btn-sm', 'btn-outline-secondary', 'mt-2');
            toggleButton.textContent = 'Show More';
            
            toggleButton.addEventListener('click', function() {
                if (codeContent.style.maxHeight === '200px') {
                    codeContent.style.maxHeight = codeHeight + 'px';
                    this.textContent = 'Show Less';
                } else {
                    codeContent.style.maxHeight = '200px';
                    this.textContent = 'Show More';
                }
            });
            
            block.appendChild(toggleButton);
        }
    });

    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
});
