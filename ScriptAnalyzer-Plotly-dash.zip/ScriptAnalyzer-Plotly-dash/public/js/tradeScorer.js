/**
 * Enhanced Trade Score Calculation
 * Analyzes channels, EMAs, volume, Fibonacci levels, RSI, MACD, Bollinger Bands, and ATR to score potential trades
 */

/**
 * Calculate a score for potential short trade opportunity
 * 
 * @param {Object} data - The candle data object
 * @param {Number} candleIdx - Index of the candle to check
 * @param {Object} fibLevels - Fibonacci levels object
 * @param {Array} channels - Array of channel objects
 * @param {Array} emas - Array of EMA objects
 * @param {Number} tolerance - Tolerance for price proximity checks (default: 0.005 or 0.5%)
 * @returns {Object} Score object with total score and component scores
 */
function calculateShortTradeScore(data, candleIdx, fibLevels, channels, emas, tolerance = 0.005) {
    // Check if we have enough data
    if (candleIdx < 3 || candleIdx >= data.length) {
        return {
            score: 0,
            valid: false,
            message: "Not enough data for analysis",
            details: {
                channelScore: 0,
                boundaryScore: 0,
                fibScore: 0,
                emaScore: 0,
                volumeScore: 0,
                rsiScore: 0,
                macdScore: 0,
                bollingerScore: 0,
                atrScore: 0
            }
        };
    }

    // Initialize score components
    let channelScore = 0;
    let boundaryScore = 0;
    let fibScore = 0;
    let emaScore = 0;
    let volumeScore = 0;
    let rsiScore = 0;
    let macdScore = 0;
    let bollingerScore = 0;
    let atrScore = 0;
    let message = "";
    let details = [];

    // Get current and previous candles
    const currentCandle = data[candleIdx];
    const prevCandle = data[candleIdx - 1];
    const prevPrevCandle = data[candleIdx - 2];

    // Extract price data
    const currentHigh = currentCandle.high;
    const currentLow = currentCandle.low;
    const currentClose = currentCandle.close;
    const currentOpen = currentCandle.open;
    const prevHigh = prevCandle.high;
    const prevLow = prevCandle.low;
    const prevClose = prevCandle.close;
    const prevOpen = prevCandle.open;
    const prevPrevClose = prevPrevCandle.close;

    // Find current channel by checking which channel contains the current candle
    let currentChannel = null;
    let channelType = null;
    let channelSlope = null;
    let upperBoundary = null;
    let lowerBoundary = null;

    for (const channel of channels) {
        // Only use channels that have reached their freeze point
        // This ensures we're only trading on established channel patterns
        if (channel.isFrozen && candleIdx >= channel.freezePoint && 
            (candleIdx <= channel.end || candleIdx <= channel.extendedEnd)) {
            currentChannel = channel;
            channelType = channel.type;
            channelSlope = channel.slope;
            
            // Calculate projected upper and lower boundaries at current candle
            const timeDiff = candleIdx - channel.start;
            upperBoundary = channel.upper + channel.slope * timeDiff;
            lowerBoundary = channel.lower + channel.slope * timeDiff;
            break;
        }
    }

    // 1. Channel Analysis
    let validChannel = false;
    let slopeSuitable = false;

    if (currentChannel) {
        // For short trades, we prefer downtrend channels or flat channels
        if (channelType === 'D') {
            // Strong negative slope - excellent for short trades
            if (channelSlope < -0.1) {
                channelScore = 25;
                slopeSuitable = true;
                details.push("Strong negative slope channel - excellent for shorts");
            } 
            // Moderate negative slope - good for short trades
            else if (channelSlope < -0.05) {
                channelScore = 20;
                slopeSuitable = true;
                details.push("Moderate negative slope channel - good for shorts");
            } 
            // Mild negative slope - acceptable for short trades
            else if (channelSlope < 0) {
                channelScore = 15;
                slopeSuitable = true;
                details.push("Mild negative slope channel - acceptable for shorts");
            }
        } 
        // Flat channel - conditionally acceptable
        else if (channelType === 'F') {
            if (channelSlope < 0.05) {
                channelScore = 10;
                slopeSuitable = true;
                details.push("Flat/slightly positive slope - conditionally acceptable for shorts");
            }
        } 
        // Uptrend channel - not suitable for shorts unless near upper boundary
        else if (channelType === 'U') {
            channelScore = 5;
            details.push("Uptrend channel - less suitable for shorts, requires strong reversal signals");
        }

        validChannel = slopeSuitable;
    } else {
        details.push("No active channel detected");
    }

    // 2. Boundary Analysis - check if price has BROKEN upper boundary (not just touched)
    let nearUpperBoundary = false;
    let upperBoundaryBroken = false;

    if (upperBoundary !== null) {
        // Check if high is breaking through upper boundary
        const highRatio = currentHigh / upperBoundary;
        const prevHighRatio = prevHigh / upperBoundary;
        const prevPrevHighRatio = candleIdx > 2 ? data[candleIdx - 2].high / upperBoundary : 0;
        
        // Check for a clear break above upper boundary
        if (highRatio > 1.01) {
            boundaryScore = 25;
            nearUpperBoundary = true;
            upperBoundaryBroken = true;
            details.push(`Upper boundary BROKEN: High (${currentHigh.toFixed(2)}) > boundary (${upperBoundary.toFixed(2)})`);
        } 
        // Previous candle broke boundary and now retracing - ideal entry
        else if (prevHighRatio > 1.01 && currentClose < upperBoundary) {
            boundaryScore = 25;
            nearUpperBoundary = true;
            upperBoundaryBroken = true;
            details.push(`Upper boundary broken and now retracing - ideal short entry`);
        }
        // Multibar breakout pattern - increasingly higher peaks testing resistance
        else if (prevPrevHighRatio < prevHighRatio && prevHighRatio < highRatio && highRatio >= 0.98) {
            boundaryScore = 20;
            nearUpperBoundary = true;
            details.push(`Multiple bars testing upper boundary with increasing pressure`);
        }
        // Very close to boundary with bearish candle
        else if (highRatio >= 0.97 && highRatio <= 1.01 && currentClose < currentOpen) {
            boundaryScore = 15;
            nearUpperBoundary = true;
            details.push(`Upper boundary test with rejection (${upperBoundary.toFixed(2)})`);
        }
        // Within 5% but without other confirmation
        else if (highRatio >= 0.95 && highRatio <= 1.05) {
            boundaryScore = 5;
            nearUpperBoundary = true;
            details.push(`Price within 5% of upper boundary - watch for confirmation`);
        }
    }

    // Rest of the function remains the same...
    // 3. Fibonacci Analysis
    let fibTouched = false;
    let fibReversed = false;
    let touchedFibValue = null;
    let isFibImportant = false;
    
    // Process Fibonacci levels
    if (fibLevels && Object.keys(fibLevels).length > 0) {
        // Check different Fibonacci levels
        for (const [level, value] of Object.entries(fibLevels)) {
            // Skip 0% level for short trades
            if (level === "0%") continue;
            
            // Check for important levels for short trades
            if (level === "38.2%" || level === "50%" || level === "23.6%") {
                isFibImportant = true;
            }
            
            // Avoid taking short trades at these levels
            if (level === "78.6%" || level === "100%") {
                continue;
            }
            
            // Use more relaxed tolerance for important Fibonacci levels
            const currentTolerance = isFibImportant ? tolerance * 2 : tolerance;
            
            // Check if price touched this Fibonacci level
            const highRatio = Math.abs(currentHigh - value) / value;
            const prevHighRatio = Math.abs(prevHigh - value) / value;
            
            if (highRatio <= currentTolerance || prevHighRatio <= currentTolerance) {
                fibTouched = true;
                touchedFibValue = value;
                
                // Check for bearish reversal
                const bearishCandle = currentClose < currentOpen;
                const downtrend = currentClose < prevClose;
                
                // Price rejection threshold
                const priceRejectionThreshold = isFibImportant ? 0.1 : 0.3;
                
                // Check for price rejection
                const priceRejection = currentHigh >= value * (1 - currentTolerance) && 
                                     currentClose < (currentHigh - (currentHigh - currentLow) * priceRejectionThreshold);
                
                if (bearishCandle || downtrend || priceRejection) {
                    fibReversed = true;
                    
                    // Score based on Fibonacci level and reversal strength
                    if (isFibImportant) {
                        fibScore = 25;
                        details.push(`Important Fibonacci level ${level} (${value.toFixed(2)}) resistance with reversal`);
                    } else {
                        fibScore = 15;
                        details.push(`Fibonacci level ${level} (${value.toFixed(2)}) resistance with reversal`);
                    }
                    
                    if (bearishCandle) {
                        fibScore += 5;
                        details.push("Bearish candle detected");
                    }
                    
                    if (downtrend) {
                        fibScore += 5;
                        details.push("Downtrend from previous close detected");
                    }
                    
                    if (priceRejection) {
                        fibScore += 5;
                        details.push("Price rejection from Fibonacci level detected");
                    }
                    
                    break;
                }
            }
        }
    }

    // 4. EMA Analysis
    if (emas && emas.length > 0) {
        // Fast EMA (8) crossing below medium EMA (21) - bearish
        const ema8 = emas.find(e => e.period === 8)?.values[candleIdx];
        const ema13 = emas.find(e => e.period === 13)?.values[candleIdx];
        const ema21 = emas.find(e => e.period === 21)?.values[candleIdx];
        const ema50 = emas.find(e => e.period === 50)?.values[candleIdx];
        
        const prev_ema8 = emas.find(e => e.period === 8)?.values[candleIdx - 1];
        const prev_ema13 = emas.find(e => e.period === 13)?.values[candleIdx - 1];
        const prev_ema21 = emas.find(e => e.period === 21)?.values[candleIdx - 1];
        
        if (ema8 && ema21 && prev_ema8 && prev_ema21) {
            // Current 8 EMA below 21 EMA (bearish alignment)
            if (ema8 < ema21) {
                emaScore += 10;
                details.push("EMA 8 below EMA 21 (bearish alignment)");
                
                // Current price below 8 EMA - stronger bearish signal
                if (currentClose < ema8) {
                    emaScore += 5;
                    details.push("Price below EMA 8 (strong bearish signal)");
                }
            }
            
            // 8 EMA crossing below 21 EMA (bearish crossover)
            if (prev_ema8 >= prev_ema21 && ema8 < ema21) {
                emaScore += 15;
                details.push("EMA 8 crossing below EMA 21 (bearish crossover)");
            }
        }
        
        // Price below 50 EMA - bearish
        if (ema50 && currentClose < ema50) {
            emaScore += 10;
            details.push("Price below EMA 50 (bearish trend)");
        }
    }

    // 5. Volume Analysis
    if (currentCandle.volume !== undefined && prevCandle.volume !== undefined) {
        // Higher volume on down candles is bullish for shorts
        const isDownCandle = currentClose < currentOpen;
        const volumeIncrease = currentCandle.volume > prevCandle.volume;
        
        if (isDownCandle && volumeIncrease) {
            volumeScore = 10;
            details.push("Increased volume on bearish candle");
        }
        
        // Check for volume divergence (price up, volume down) - bearish
        const priceUp = currentClose > prevClose;
        if (priceUp && currentCandle.volume < prevCandle.volume) {
            volumeScore += 5;
            details.push("Volume declining while price rising (bearish divergence)");
        }
    }

    // 6. RSI Analysis (Relative Strength Index)
    if (currentCandle.rsi !== undefined) {
        // For short trades, high RSI values (overbought) are favorable
        if (currentCandle.rsi > 70) {
            rsiScore = 15;
            details.push(`RSI is overbought (${currentCandle.rsi.toFixed(2)}) - favorable for shorts`);
        } 
        // RSI above 60 is still relatively high
        else if (currentCandle.rsi > 60) {
            rsiScore = 10;
            details.push(`RSI is elevated (${currentCandle.rsi.toFixed(2)}) - moderately favorable for shorts`);
        }
        
        // RSI declining from previous candle is bearish
        if (prevCandle.rsi !== undefined && currentCandle.rsi < prevCandle.rsi) {
            rsiScore += 5;
            details.push(`RSI declining from ${prevCandle.rsi.toFixed(2)} to ${currentCandle.rsi.toFixed(2)} - bearish momentum`);
            
            // RSI falling from overbought
            if (prevCandle.rsi > 70 && currentCandle.rsi < 70) {
                rsiScore += 5;
                details.push("RSI falling from overbought territory - strong bearish signal");
            }
        }
    }

    // 7. MACD Analysis (Moving Average Convergence Divergence)
    if (currentCandle.macd !== undefined && currentCandle.macd.macd !== undefined) {
        const macd = currentCandle.macd;
        const prevMacd = prevCandle.macd;
        
        // MACD below signal line is bearish
        if (macd.signal !== undefined && macd.macd < macd.signal) {
            macdScore += 10;
            details.push("MACD below signal line - bearish alignment");
            
            // MACD histogram negative and expanding
            if (macd.histogram !== undefined && prevMacd?.histogram !== undefined) {
                if (macd.histogram < 0 && macd.histogram < prevMacd.histogram) {
                    macdScore += 5;
                    details.push("MACD histogram negative and expanding - increasing bearish momentum");
                }
            }
        }
        
        // MACD crossing below signal line (bearish crossover)
        if (prevMacd?.macd !== undefined && prevMacd?.signal !== undefined) {
            if (prevMacd.macd > prevMacd.signal && macd.macd < macd.signal) {
                macdScore += 15;
                details.push("MACD crossing below signal line - bearish crossover");
            }
        }
        
        // MACD value negative
        if (macd.macd < 0) {
            macdScore += 5;
            details.push("MACD value is negative - bearish trend");
        }
    }

    // 8. Bollinger Bands Analysis
    if (currentCandle.bollinger !== undefined && 
        currentCandle.bollinger.upper !== undefined && 
        currentCandle.bollinger.middle !== undefined &&
        currentCandle.bollinger.lower !== undefined) {
        
        const bands = currentCandle.bollinger;
        
        // Price near or above upper band (potential reversal zone for shorts)
        if (currentHigh >= bands.upper * 0.98) {
            bollingerScore += 15;
            details.push(`Price near/above upper Bollinger Band (${bands.upper.toFixed(2)}) - potential reversal zone`);
            
            // Bearish candle at upper band
            if (currentClose < currentOpen && currentHigh >= bands.upper * 0.98) {
                bollingerScore += 10;
                details.push("Bearish candle at upper Bollinger Band - strong reversal signal");
            }
        }
        
        // Bollinger Band squeeze (narrowing bands) - potential breakout setup
        if (prevCandle.bollinger !== undefined) {
            const prevWidth = prevCandle.bollinger.upper - prevCandle.bollinger.lower;
            const currWidth = bands.upper - bands.lower;
            
            if (currWidth < prevWidth) {
                bollingerScore += 5;
                details.push("Bollinger Bands narrowing - potential breakout setup");
            }
        }
    }

    // 9. ATR Analysis (Average True Range) - volatility assessment
    if (currentCandle.atr !== undefined) {
        const atr = currentCandle.atr;
        
        // Calculate ATR as percentage of price for normalized volatility
        const atrPercent = (atr / currentClose) * 100;
        
        // Higher volatility is often better for tactical short entries
        if (atrPercent >= 1.5) {  // More than 1.5% volatility is significant
            atrScore += 10;
            details.push(`High volatility (ATR: ${atrPercent.toFixed(2)}%) - favorable for short trade execution`);
        } else if (atrPercent >= 0.8) {  // Moderate volatility
            atrScore += 5;
            details.push(`Moderate volatility (ATR: ${atrPercent.toFixed(2)}%) - acceptable for short trades`);
        } else {
            details.push(`Low volatility (ATR: ${atrPercent.toFixed(2)}%) - may result in slow price movement`);
        }
    }

    // Calculate total score
    const totalScore = channelScore + boundaryScore + fibScore + emaScore + 
                       volumeScore + rsiScore + macdScore + bollingerScore + atrScore;
    
    // Normalize score to a maximum of 100
    const normalizedScore = Math.min(totalScore, 100);
    
    // Check if this is a valid short signal
    // Key requirements: Upper boundary break and bearish signals
    const isValid = upperBoundaryBroken && fibReversed && (normalizedScore >= 90);
    
    // Set the message based on validation
    if (isValid) {
        message = `High-quality short signal (${normalizedScore.toFixed(0)}% strength) at upper channel boundary with Fibonacci reversal`;
    } else if (upperBoundaryBroken && fibReversed) {
        message = `Potential short opportunity (${normalizedScore.toFixed(0)}% strength) - channel boundary break with Fibonacci reversal`;
    } else if (upperBoundaryBroken) {
        message = `Channel upper boundary broken but lacks confirmation (${normalizedScore.toFixed(0)}% strength)`;
    } else if (nearUpperBoundary) {
        message = `Price near upper channel boundary (${normalizedScore.toFixed(0)}% strength) - monitor for breakout`;
    } else {
        message = `Not a valid short opportunity (${normalizedScore.toFixed(0)}% strength)`;
    }
    
    return {
        score: normalizedScore,
        valid: isValid,
        message: message,
        details: details,
        detailedScores: {
            channelScore,
            boundaryScore,
            fibScore,
            emaScore,
            volumeScore,
            rsiScore,
            macdScore,
            bollingerScore,
            atrScore
        },
        channelBoundaries: {
            upper: upperBoundary,
            lower: lowerBoundary
        },
        fibLevel: touchedFibValue
    };
}

/**
 * Calculate a score for potential long trade opportunity
 * 
 * @param {Object} data - The candle data object
 * @param {Number} candleIdx - Index of the candle to check
 * @param {Object} fibLevels - Fibonacci levels object
 * @param {Array} channels - Array of channel objects
 * @param {Array} emas - Array of EMA objects
 * @param {Number} tolerance - Tolerance for price proximity checks (default: 0.005 or 0.5%)
 * @returns {Object} Score object with total score and component scores
 */
function calculateLongTradeScore(data, candleIdx, fibLevels, channels, emas, tolerance = 0.005) {
    // Check if we have enough data
    if (candleIdx < 3 || candleIdx >= data.length) {
        return {
            score: 0,
            valid: false,
            message: "Not enough data for analysis",
            details: {
                channelScore: 0,
                boundaryScore: 0,
                fibScore: 0,
                emaScore: 0,
                volumeScore: 0,
                rsiScore: 0,
                macdScore: 0,
                bollingerScore: 0,
                atrScore: 0
            }
        };
    }

    // Initialize score components
    let channelScore = 0;
    let boundaryScore = 0;
    let fibScore = 0;
    let emaScore = 0;
    let volumeScore = 0;
    let rsiScore = 0;
    let macdScore = 0;
    let bollingerScore = 0;
    let atrScore = 0;
    let message = "";
    let details = [];

    // Get current and previous candles
    const currentCandle = data[candleIdx];
    const prevCandle = data[candleIdx - 1];
    const prevPrevCandle = data[candleIdx - 2];

    // Extract price data
    const currentHigh = currentCandle.high;
    const currentLow = currentCandle.low;
    const currentClose = currentCandle.close;
    const currentOpen = currentCandle.open;
    const prevHigh = prevCandle.high;
    const prevLow = prevCandle.low;
    const prevClose = prevCandle.close;
    const prevOpen = prevCandle.open;
    const prevPrevClose = prevPrevCandle.close;

    // Find current channel at candle index
    let currentChannel = null;
    let channelType = null;
    let channelSlope = null;
    let upperBoundary = null;
    let lowerBoundary = null;

    for (const channel of channels) {
        // Only use channels that have reached their freeze point
        // This ensures we're only trading on established channel patterns
        if (channel.isFrozen && candleIdx >= channel.freezePoint && 
            (candleIdx <= channel.end || candleIdx <= channel.extendedEnd)) {
            currentChannel = channel;
            channelType = channel.type;
            channelSlope = channel.slope;
            
            // Calculate projected upper and lower boundaries at current candle
            const timeDiff = candleIdx - channel.start;
            upperBoundary = channel.upper + channel.slope * timeDiff;
            lowerBoundary = channel.lower + channel.slope * timeDiff;
            break;
        }
    }

    // 1. Channel Analysis
    let validChannel = false;
    let slopeSuitable = false;

    if (currentChannel) {
        // For long trades, we prefer uptrend channels or flat channels
        if (channelType === 'U') {
            // Strong positive slope - excellent for long trades
            if (channelSlope > 0.1) {
                channelScore = 25;
                slopeSuitable = true;
                details.push("Strong positive slope channel - excellent for longs");
            } 
            // Moderate positive slope - good for long trades
            else if (channelSlope > 0.05) {
                channelScore = 20;
                slopeSuitable = true;
                details.push("Moderate positive slope channel - good for longs");
            } 
            // Mild positive slope - acceptable for long trades
            else if (channelSlope > 0) {
                channelScore = 15;
                slopeSuitable = true;
                details.push("Mild positive slope channel - acceptable for longs");
            }
        } 
        // Flat channel - conditionally acceptable
        else if (channelType === 'F') {
            if (channelSlope > -0.05) {
                channelScore = 10;
                slopeSuitable = true;
                details.push("Flat/slightly negative slope - conditionally acceptable for longs");
            }
        } 
        // Downtrend channel - not suitable for longs unless near lower boundary
        else if (channelType === 'D') {
            channelScore = 5;
            details.push("Downtrend channel - less suitable for longs, requires strong reversal signals");
        }

        validChannel = slopeSuitable;
    } else {
        details.push("No active channel detected");
    }

    // 2. Boundary Analysis - check if price has BROKEN lower boundary (not just touched)
    let nearLowerBoundary = false;
    let lowerBoundaryBroken = false;

    if (lowerBoundary !== null) {
        // Check if low is breaking through lower boundary
        const lowRatio = lowerBoundary / currentLow;
        const prevLowRatio = lowerBoundary / prevLow;
        const prevPrevLowRatio = candleIdx > 2 ? lowerBoundary / data[candleIdx - 2].low : 0;
        
        // Check for a clear break below lower boundary
        if (lowRatio > 1.01) {
            boundaryScore = 25;
            nearLowerBoundary = true;
            lowerBoundaryBroken = true;
            details.push(`Lower boundary BROKEN: Low (${currentLow.toFixed(2)}) < boundary (${lowerBoundary.toFixed(2)})`);
        } 
        // Previous candle broke boundary and now retracing - ideal entry
        else if (prevLowRatio > 1.01 && currentClose > lowerBoundary) {
            boundaryScore = 25;
            nearLowerBoundary = true;
            lowerBoundaryBroken = true;
            details.push(`Lower boundary broken and now retracing - ideal long entry`);
        }
        // Multibar breakout pattern - increasingly lower lows testing support
        else if (prevPrevLowRatio < prevLowRatio && prevLowRatio < lowRatio && lowRatio >= 0.98) {
            boundaryScore = 20;
            nearLowerBoundary = true;
            details.push(`Multiple bars testing lower boundary with increasing pressure`);
        }
        // Very close to boundary with bullish candle
        else if (lowRatio >= 0.97 && lowRatio <= 1.01 && currentClose > currentOpen) {
            boundaryScore = 15;
            nearLowerBoundary = true;
            details.push(`Lower boundary test with rejection (${lowerBoundary.toFixed(2)})`);
        }
        // Within 5% but without other confirmation
        else if (lowRatio >= 0.95 && lowRatio <= 1.05) {
            boundaryScore = 5;
            nearLowerBoundary = true;
            details.push(`Price within 5% of lower boundary - watch for confirmation`);
        }
    }

    // 3. Fibonacci Analysis
    let fibTouched = false;
    let fibReversed = false;
    let touchedFibValue = null;
    let isFibImportant = false;
    
    // Process Fibonacci levels
    if (fibLevels && Object.keys(fibLevels).length > 0) {
        // Check different Fibonacci levels
        for (const [level, value] of Object.entries(fibLevels)) {
            // Skip 100% level for long trades
            if (level === "100%") continue;
            
            // Check for important levels for long trades
            if (level === "61.8%" || level === "50%" || level === "78.6%") {
                isFibImportant = true;
            }
            
            // Avoid taking long trades at these levels
            if (level === "23.6%" || level === "0%") {
                continue;
            }
            
            // Use more relaxed tolerance for important Fibonacci levels
            const currentTolerance = isFibImportant ? tolerance * 2 : tolerance;
            
            // Check if price touched this Fibonacci level
            const lowRatio = Math.abs(currentLow - value) / value;
            const prevLowRatio = Math.abs(prevLow - value) / value;
            
            if (lowRatio <= currentTolerance || prevLowRatio <= currentTolerance) {
                fibTouched = true;
                touchedFibValue = value;
                
                // Check for bullish reversal
                const bullishCandle = currentClose > currentOpen;
                const uptrend = currentClose > prevClose;
                
                // Price rejection threshold
                const priceRejectionThreshold = isFibImportant ? 0.1 : 0.3;
                
                // Check for price rejection
                const priceRejection = currentLow <= value * (1 + currentTolerance) && 
                                     currentClose > (currentLow + (currentHigh - currentLow) * priceRejectionThreshold);
                
                if (bullishCandle || uptrend || priceRejection) {
                    fibReversed = true;
                    
                    // Score based on Fibonacci level and reversal strength
                    if (isFibImportant) {
                        fibScore = 25;
                        details.push(`Important Fibonacci level ${level} (${value.toFixed(2)}) support with reversal`);
                    } else {
                        fibScore = 15;
                        details.push(`Fibonacci level ${level} (${value.toFixed(2)}) support with reversal`);
                    }
                    
                    if (bullishCandle) {
                        fibScore += 5;
                        details.push("Bullish candle detected");
                    }
                    
                    if (uptrend) {
                        fibScore += 5;
                        details.push("Uptrend from previous close detected");
                    }
                    
                    if (priceRejection) {
                        fibScore += 5;
                        details.push("Price rejection from Fibonacci level detected");
                    }
                    
                    break;
                }
            }
        }
    }

    // 4. EMA Analysis
    if (emas && emas.length > 0) {
        // Fast EMA (8) crossing above medium EMA (21) - bullish
        const ema8 = emas.find(e => e.period === 8)?.values[candleIdx];
        const ema13 = emas.find(e => e.period === 13)?.values[candleIdx];
        const ema21 = emas.find(e => e.period === 21)?.values[candleIdx];
        const ema50 = emas.find(e => e.period === 50)?.values[candleIdx];
        
        const prev_ema8 = emas.find(e => e.period === 8)?.values[candleIdx - 1];
        const prev_ema13 = emas.find(e => e.period === 13)?.values[candleIdx - 1];
        const prev_ema21 = emas.find(e => e.period === 21)?.values[candleIdx - 1];
        
        if (ema8 && ema21 && prev_ema8 && prev_ema21) {
            // Current 8 EMA above 21 EMA (bullish alignment)
            if (ema8 > ema21) {
                emaScore += 10;
                details.push("EMA 8 above EMA 21 (bullish alignment)");
                
                // Current price above 8 EMA - stronger bullish signal
                if (currentClose > ema8) {
                    emaScore += 5;
                    details.push("Price above EMA 8 (strong bullish signal)");
                }
            }
            
            // 8 EMA crossing above 21 EMA (bullish crossover)
            if (prev_ema8 <= prev_ema21 && ema8 > ema21) {
                emaScore += 15;
                details.push("EMA 8 crossing above EMA 21 (bullish crossover)");
            }
        }
        
        // Price above 50 EMA - bullish
        if (ema50 && currentClose > ema50) {
            emaScore += 10;
            details.push("Price above EMA 50 (bullish trend)");
        }
    }

    // 5. Volume Analysis
    if (currentCandle.volume !== undefined && prevCandle.volume !== undefined) {
        // Higher volume on up candles is bullish for longs
        const isUpCandle = currentClose > currentOpen;
        const volumeIncrease = currentCandle.volume > prevCandle.volume;
        
        if (isUpCandle && volumeIncrease) {
            volumeScore = 10;
            details.push("Increased volume on bullish candle");
        }
        
        // Check for volume divergence (price down, volume down) - bullish
        const priceDown = currentClose < prevClose;
        if (priceDown && currentCandle.volume < prevCandle.volume) {
            volumeScore += 5;
            details.push("Volume declining while price falling (bullish divergence)");
        }
    }

    // 6. RSI Analysis (Relative Strength Index)
    if (currentCandle.rsi !== undefined) {
        // For long trades, low RSI values (oversold) are favorable
        if (currentCandle.rsi < 30) {
            rsiScore = 15;
            details.push(`RSI is oversold (${currentCandle.rsi.toFixed(2)}) - favorable for longs`);
        } 
        // RSI below 40 is still relatively low
        else if (currentCandle.rsi < 40) {
            rsiScore = 10;
            details.push(`RSI is depressed (${currentCandle.rsi.toFixed(2)}) - moderately favorable for longs`);
        }
        
        // RSI rising from previous candle is bullish
        if (prevCandle.rsi !== undefined && currentCandle.rsi > prevCandle.rsi) {
            rsiScore += 5;
            details.push(`RSI rising from ${prevCandle.rsi.toFixed(2)} to ${currentCandle.rsi.toFixed(2)} - bullish momentum`);
            
            // RSI rising from oversold
            if (prevCandle.rsi < 30 && currentCandle.rsi > 30) {
                rsiScore += 5;
                details.push("RSI rising from oversold territory - strong bullish signal");
            }
        }
    }

    // 7. MACD Analysis (Moving Average Convergence Divergence)
    if (currentCandle.macd !== undefined && currentCandle.macd.macd !== undefined) {
        const macd = currentCandle.macd;
        const prevMacd = prevCandle.macd;
        
        // MACD above signal line is bullish
        if (macd.signal !== undefined && macd.macd > macd.signal) {
            macdScore += 10;
            details.push("MACD above signal line - bullish alignment");
            
            // MACD histogram positive and expanding
            if (macd.histogram !== undefined && prevMacd?.histogram !== undefined) {
                if (macd.histogram > 0 && macd.histogram > prevMacd.histogram) {
                    macdScore += 5;
                    details.push("MACD histogram positive and expanding - increasing bullish momentum");
                }
            }
        }
        
        // MACD crossing above signal line (bullish crossover)
        if (prevMacd?.macd !== undefined && prevMacd?.signal !== undefined) {
            if (prevMacd.macd < prevMacd.signal && macd.macd > macd.signal) {
                macdScore += 15;
                details.push("MACD crossing above signal line - bullish crossover");
            }
        }
        
        // MACD value positive
        if (macd.macd > 0) {
            macdScore += 5;
            details.push("MACD value is positive - bullish trend");
        }
    }

    // 8. Bollinger Bands Analysis
    if (currentCandle.bollinger !== undefined && 
        currentCandle.bollinger.upper !== undefined && 
        currentCandle.bollinger.middle !== undefined &&
        currentCandle.bollinger.lower !== undefined) {
        
        const bands = currentCandle.bollinger;
        
        // Price near or below lower band (potential reversal zone for longs)
        if (currentLow <= bands.lower * 1.02) {
            bollingerScore += 15;
            details.push(`Price near/below lower Bollinger Band (${bands.lower.toFixed(2)}) - potential reversal zone`);
            
            // Bullish candle at lower band
            if (currentClose > currentOpen && currentLow <= bands.lower * 1.02) {
                bollingerScore += 10;
                details.push("Bullish candle at lower Bollinger Band - strong reversal signal");
            }
        }
        
        // Bollinger Band squeeze (narrowing bands) - potential breakout setup
        if (prevCandle.bollinger !== undefined) {
            const prevWidth = prevCandle.bollinger.upper - prevCandle.bollinger.lower;
            const currWidth = bands.upper - bands.lower;
            
            if (currWidth < prevWidth) {
                bollingerScore += 5;
                details.push("Bollinger Bands narrowing - potential breakout setup");
            }
        }
    }

    // 9. ATR Analysis (Average True Range) - volatility assessment
    if (currentCandle.atr !== undefined) {
        const atr = currentCandle.atr;
        
        // Calculate ATR as percentage of price for normalized volatility
        const atrPercent = (atr / currentClose) * 100;
        
        // Higher volatility is often better for tactical long entries
        if (atrPercent >= 1.5) {  // More than 1.5% volatility is significant
            atrScore += 10;
            details.push(`High volatility (ATR: ${atrPercent.toFixed(2)}%) - favorable for long trade execution`);
        } else if (atrPercent >= 0.8) {  // Moderate volatility
            atrScore += 5;
            details.push(`Moderate volatility (ATR: ${atrPercent.toFixed(2)}%) - acceptable for long trades`);
        } else {
            details.push(`Low volatility (ATR: ${atrPercent.toFixed(2)}%) - may result in slow price movement`);
        }
    }

    // Calculate total score
    const totalScore = channelScore + boundaryScore + fibScore + emaScore + 
                       volumeScore + rsiScore + macdScore + bollingerScore + atrScore;
    
    // Normalize score to a maximum of 100
    const normalizedScore = Math.min(totalScore, 100);
    
    // Check if this is a valid long signal
    // Key requirements: Lower boundary break and bullish signals
    const isValid = lowerBoundaryBroken && fibReversed && (normalizedScore >= 90);
    
    // Set the message based on validation
    if (isValid) {
        message = `High-quality long signal (${normalizedScore.toFixed(0)}% strength) at lower channel boundary with Fibonacci reversal`;
    } else if (lowerBoundaryBroken && fibReversed) {
        message = `Potential long opportunity (${normalizedScore.toFixed(0)}% strength) - channel boundary break with Fibonacci reversal`;
    } else if (lowerBoundaryBroken) {
        message = `Channel lower boundary broken but lacks confirmation (${normalizedScore.toFixed(0)}% strength)`;
    } else if (nearLowerBoundary) {
        message = `Price near lower channel boundary (${normalizedScore.toFixed(0)}% strength) - monitor for breakout`;
    } else {
        message = `Not a valid long opportunity (${normalizedScore.toFixed(0)}% strength)`;
    }
    
    return {
        score: normalizedScore,
        valid: isValid,
        message: message,
        details: details,
        detailedScores: {
            channelScore,
            boundaryScore,
            fibScore,
            emaScore,
            volumeScore,
            rsiScore,
            macdScore,
            bollingerScore,
            atrScore
        },
        channelBoundaries: {
            upper: upperBoundary,
            lower: lowerBoundary
        },
        fibLevel: touchedFibValue
    };
}