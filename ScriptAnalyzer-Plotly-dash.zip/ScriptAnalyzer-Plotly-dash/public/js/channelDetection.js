/**
 * Channel Detection Algorithm for Stock Analysis
 * JavaScript implementation for price channel analysis
 */

/**
 * Linear regression implementation
 * @param {Array} x - X values
 * @param {Array} y - Y values
 * @returns {Object} Regression results including slope, intercept, and r-squared
 */
function linearRegression(x, y) {
    const n = x.length;
    
    if (n === 0 || n !== y.length) {
        return { slope: NaN, intercept: NaN, r2: 0 };
    }
    
    // Calculate means
    let sumX = 0, sumY = 0;
    for (let i = 0; i < n; i++) {
        sumX += x[i];
        sumY += y[i];
    }
    const meanX = sumX / n;
    const meanY = sumY / n;
    
    // Calculate slope and intercept
    let numerator = 0, denominator = 0;
    for (let i = 0; i < n; i++) {
        const xDiff = x[i] - meanX;
        numerator += xDiff * (y[i] - meanY);
        denominator += xDiff * xDiff;
    }
    
    // Handle zero denominator
    if (denominator === 0) {
        return { slope: 0, intercept: meanY, r2: 0 };
    }
    
    const slope = numerator / denominator;
    const intercept = meanY - slope * meanX;
    
    // Calculate R-squared
    let SSE = 0, SST = 0;
    for (let i = 0; i < n; i++) {
        const yPred = slope * x[i] + intercept;
        SSE += Math.pow(y[i] - yPred, 2);
        SST += Math.pow(y[i] - meanY, 2);
    }
    
    // Handle zero SST
    const r2 = (SST === 0) ? 0 : 1 - (SSE / SST);
    
    return { slope, intercept, r2 };
}

/**
 * Find significant points (local highs and lows) in the price data
 * @param {Array} data - Array of price objects with high and low properties
 * @param {Number} lookback - Number of periods to look back for comparison
 * @returns {Object} Object with arrays of indices for highs and lows
 */
function findSignificantPoints(data, lookback = 3) {
    const highs = [];
    const lows = [];
    
    if (!data || data.length <= 2 * lookback) {
        return { highs, lows };
    }
    
    // Process each data point
    for (let i = lookback; i < data.length - lookback; i++) {
        // Check for high point
        let isHighPoint = true;
        for (let j = i - lookback; j < i; j++) {
            if (data[i].high <= data[j].high) {
                isHighPoint = false;
                break;
            }
        }
        
        if (isHighPoint) {
            for (let j = i + 1; j <= i + lookback; j++) {
                if (data[i].high <= data[j].high) {
                    isHighPoint = false;
                    break;
                }
            }
        }
        
        if (isHighPoint) {
            highs.push(i);
        }
        
        // Check for low point
        let isLowPoint = true;
        for (let j = i - lookback; j < i; j++) {
            if (data[i].low >= data[j].low) {
                isLowPoint = false;
                break;
            }
        }
        
        if (isLowPoint) {
            for (let j = i + 1; j <= i + lookback; j++) {
                if (data[i].low >= data[j].low) {
                    isLowPoint = false;
                    break;
                }
            }
        }
        
        if (isLowPoint) {
            lows.push(i);
        }
    }
    
    return { highs, lows };
}

/**
 * Calculate EMAs for the dataset
 * @param {Array} data - Array of price objects with close property
 * @returns {Array} Data with EMA properties added
 */
/**
 * Calculate Relative Strength Index (RSI)
 * @param {Array} data - Array of price objects with close property
 * @param {Number} period - RSI period (default: 14)
 * @returns {Array} Data with RSI property added
 */
function calculateRSI(data, period = 14) {
    // Clone data to avoid modifying the original
    const result = JSON.parse(JSON.stringify(data));
    
    if (result.length <= period) {
        return result;
    }
    
    // Initialize RSI as undefined for all data points
    for (let i = 0; i < result.length; i++) {
        result[i].rsi = undefined;
    }
    
    let gains = 0;
    let losses = 0;
    
    // Calculate first average gain and loss
    for (let i = 1; i <= period; i++) {
        const change = result[i].close - result[i-1].close;
        if (change >= 0) {
            gains += change;
        } else {
            losses += Math.abs(change);
        }
    }
    
    // Initial averages
    let avgGain = gains / period;
    let avgLoss = losses / period;
    
    // Calculate RS and RSI for the first period point
    let rs = avgGain / (avgLoss === 0 ? 0.001 : avgLoss); // Avoid division by zero
    result[period].rsi = 100 - (100 / (1 + rs));
    
    // Calculate smoothed RS and RSI for the remaining points
    for (let i = period + 1; i < result.length; i++) {
        const change = result[i].close - result[i-1].close;
        let currentGain = 0;
        let currentLoss = 0;
        
        if (change >= 0) {
            currentGain = change;
        } else {
            currentLoss = Math.abs(change);
        }
        
        // Use Wilder's smoothing method
        avgGain = ((avgGain * (period - 1)) + currentGain) / period;
        avgLoss = ((avgLoss * (period - 1)) + currentLoss) / period;
        
        rs = avgGain / (avgLoss === 0 ? 0.001 : avgLoss); // Avoid division by zero
        result[i].rsi = 100 - (100 / (1 + rs));
    }
    
    return result;
}

/**
 * Calculate MACD (Moving Average Convergence Divergence)
 * @param {Array} data - Array of price objects with close property
 * @param {Object} options - MACD parameters
 * @returns {Array} Data with MACD properties added
 */
function calculateMACD(data, options = {}) {
    const fastPeriod = options.fastPeriod || 12;
    const slowPeriod = options.slowPeriod || 26;
    const signalPeriod = options.signalPeriod || 9;
    
    // Clone data to avoid modifying the original
    const result = JSON.parse(JSON.stringify(data));
    
    if (result.length <= slowPeriod) {
        return result;
    }
    
    // Initialize all MACD properties to undefined
    for (let i = 0; i < result.length; i++) {
        result[i].macd = undefined;
        result[i].macdSignal = undefined;
        result[i].macdHistogram = undefined;
        result[i].macdFastEMA = undefined;
        result[i].macdSlowEMA = undefined;
    }
    
    // Calculate EMAs for fast and slow periods
    let fastEMA = 0;
    let slowEMA = 0;
    let fastK = 2 / (fastPeriod + 1);
    let slowK = 2 / (slowPeriod + 1);
    let signalK = 2 / (signalPeriod + 1);
    
    // Calculate initial EMAs (using SMA for the first value)
    let fastSum = 0;
    let slowSum = 0;
    
    for (let i = 0; i < slowPeriod; i++) {
        const price = result[i].close;
        slowSum += price;
        if (i >= slowPeriod - fastPeriod) {
            fastSum += price;
        }
    }
    
    fastEMA = fastSum / fastPeriod;
    slowEMA = slowSum / slowPeriod;
    
    // Set EMAs for the first point where we can calculate MACD
    result[slowPeriod - 1].macdFastEMA = fastEMA;
    result[slowPeriod - 1].macdSlowEMA = slowEMA;
    result[slowPeriod - 1].macd = fastEMA - slowEMA;
    
    // Calculate MACD for remaining points
    let macdSum = 0;
    for (let i = slowPeriod; i < result.length; i++) {
        const price = result[i].close;
        
        // Calculate EMAs
        fastEMA = price * fastK + fastEMA * (1 - fastK);
        slowEMA = price * slowK + slowEMA * (1 - slowK);
        
        // Calculate MACD line (fast EMA - slow EMA)
        const macd = fastEMA - slowEMA;
        
        result[i].macdFastEMA = fastEMA;
        result[i].macdSlowEMA = slowEMA;
        result[i].macd = macd;
        
        // Collect MACD values for signal line calculation
        if (i < slowPeriod + signalPeriod - 1) {
            macdSum += macd;
            
            // Set initial signal line when we have enough data
            if (i === slowPeriod + signalPeriod - 2) {
                const signalLine = macdSum / signalPeriod;
                result[i].macdSignal = signalLine;
                result[i].macdHistogram = macd - signalLine;
            }
        } else {
            // Calculate signal line (EMA of MACD)
            const prevSignal = result[i-1].macdSignal;
            const signalLine = macd * signalK + prevSignal * (1 - signalK);
            
            result[i].macdSignal = signalLine;
            result[i].macdHistogram = macd - signalLine;
        }
    }
    
    return result;
}

/**
 * Calculate Bollinger Bands
 * @param {Array} data - Array of price objects with close property
 * @param {Number} period - Period for moving average (default: 20)
 * @param {Number} stdDevMultiplier - Multiplier for standard deviation (default: 2)
 * @returns {Array} Data with Bollinger Bands properties added
 */
function calculateBollingerBands(data, period = 20, stdDevMultiplier = 2) {
    // Clone data to avoid modifying the original
    const result = JSON.parse(JSON.stringify(data));
    
    if (result.length < period) return result;
    
    // Initialize Bollinger Band properties for all data points
    for (let i = 0; i < result.length; i++) {
        result[i].bollingerMiddle = undefined;
        result[i].bollingerUpper = undefined;
        result[i].bollingerLower = undefined;
    }
    
    for (let i = period - 1; i < result.length; i++) {
        // Calculate simple moving average
        let sum = 0;
        for (let j = 0; j < period; j++) {
            sum += result[i - j].close;
        }
        const sma = sum / period;
        
        // Calculate standard deviation
        let sumSquaredDiff = 0;
        for (let j = 0; j < period; j++) {
            const diff = result[i - j].close - sma;
            sumSquaredDiff += diff * diff;
        }
        const stdDev = Math.sqrt(sumSquaredDiff / period);
        
        // Calculate Bollinger Bands
        result[i].bollingerMiddle = sma;
        result[i].bollingerUpper = sma + (stdDevMultiplier * stdDev);
        result[i].bollingerLower = sma - (stdDevMultiplier * stdDev);
    }
    
    return result;
}

/**
 * Calculate Average True Range (ATR)
 * @param {Array} data - Array of price objects with high, low, close properties
 * @param {Number} period - ATR period (default: 14)
 * @returns {Array} Data with ATR property added
 */
function calculateATR(data, period = 14) {
    // Clone data to avoid modifying the original
    const result = JSON.parse(JSON.stringify(data));
    
    if (result.length <= period) return result;
    
    // Initialize all ATR values as undefined
    for (let i = 0; i < result.length; i++) {
        result[i].atr = undefined;
        result[i].trueRange = undefined;
    }
    
    // Calculate True Range for each point
    for (let i = 1; i < result.length; i++) {
        const high = result[i].high;
        const low = result[i].low;
        const prevClose = result[i-1].close;
        
        // True Range is the greatest of:
        // 1. Current High - Current Low
        // 2. |Current High - Previous Close|
        // 3. |Current Low - Previous Close|
        const tr1 = high - low;
        const tr2 = Math.abs(high - prevClose);
        const tr3 = Math.abs(low - prevClose);
        
        result[i].trueRange = Math.max(tr1, tr2, tr3);
    }
    
    // Calculate first ATR as simple average of TR for the first 'period' days
    let sum = 0;
    for (let i = 1; i <= period; i++) {
        sum += result[i].trueRange;
    }
    result[period].atr = sum / period;
    
    // Calculate ATR using smoothing for the remaining data points
    for (let i = period + 1; i < result.length; i++) {
        // Wilder's smoothing method: ATR = ((ATR_prev * (period - 1)) + TR_current) / period
        result[i].atr = ((result[i-1].atr * (period - 1)) + result[i].trueRange) / period;
    }
    
    return result;
}

function calculateEMAs(data) {
    const periods = [8, 13, 21, 50];
    
    // Clone data to avoid modifying the original
    const result = JSON.parse(JSON.stringify(data));
    
    // Calculate EMAs for each period
    for (const period of periods) {
        const k = 2 / (period + 1);
        const emaKey = `ema${period}`;
        
        // Initialize EMA with SMA for the first 'period' elements
        let sum = 0;
        for (let i = 0; i < period && i < result.length; i++) {
            sum += result[i].close;
        }
        
        if (result.length >= period) {
            result[period - 1][emaKey] = sum / period;
            
            // Calculate EMA for remaining elements
            for (let i = period; i < result.length; i++) {
                result[i][emaKey] = (result[i].close * k) + (result[i - 1][emaKey] * (1 - k));
            }
        }
    }
    
    return result;
}

/**
 * Determine trend based on EMAs
 * @param {Array} data - Array of price objects with EMAs
 * @param {Number} currentIdx - Current index to check
 * @param {Number} lookback - Lookback period
 * @returns {Object} Trend information
 */
function determineTrend(data, currentIdx, lookback = 20) {
    // Ensure we have enough data and EMAs exist
    if (currentIdx < lookback || 
        !data[currentIdx].ema8 || 
        !data[currentIdx].ema21 || 
        !data[currentIdx].ema50) {
        return { trend: "FLAT", emaSupport: false };
    }
    
    // Get current EMAs
    const currentEma8 = data[currentIdx].ema8;
    const currentEma21 = data[currentIdx].ema21;
    const currentEma50 = data[currentIdx].ema50;
    
    // Get previous EMAs (5 periods ago)
    const prevIdx = Math.max(0, currentIdx - 5);
    
    if (!data[prevIdx].ema8 || !data[prevIdx].ema21) {
        return { trend: "FLAT", emaSupport: false };
    }
    
    const prevEma8 = data[prevIdx].ema8;
    const prevEma21 = data[prevIdx].ema21;
    
    // Check EMA alignment for trend
    if (currentEma8 > currentEma21 && 
        currentEma21 > currentEma50 && 
        currentEma8 > prevEma8) {
        return { trend: "UP", emaSupport: true };
    } else if (currentEma8 < currentEma21 && 
              currentEma21 < currentEma50 && 
              currentEma8 < prevEma8) {
        return { trend: "DOWN", emaSupport: true };
    } else if (currentEma8 > currentEma21 && currentEma8 > prevEma8) {
        return { trend: "UP", emaSupport: false };
    } else if (currentEma8 < currentEma21 && currentEma8 < prevEma8) {
        return { trend: "DOWN", emaSupport: false };
    } else {
        return { trend: "FLAT", emaSupport: false };
    }
}

/**
 * Find price channels in the stock data
 * @param {Array} data - Array of price objects
 * @param {Number} window - Window size for channel detection
 * @param {Number} minR2 - Minimum R-squared value for valid channels
 * @returns {Array} Array of channel objects including freezePoint property
 */
function findChannels(data, window = 5, minR2 = 0.7) {
    if (!data || data.length < window) {
        return [];
    }
    
    // Add EMAs to data
    const dataWithEMAs = calculateEMAs(data);
    
    // Find significant points
    const sigPoints = findSignificantPoints(dataWithEMAs);
    
    // Calculate minimum channel height (1% of total range)
    const minChannelHeight = (Math.max(...dataWithEMAs.map(d => d.high)) - 
                            Math.min(...dataWithEMAs.map(d => d.low))) * 0.01;
    
    // Minimum time between channels
    const minChannelGap = 5;
    
    // Minimum segment length
    const minSegment = 10;
    
    // Array to store detected channels
    const channels = [];
    
    // Function to fit a channel
    function fitChannel(startIdx, endIdx) {
        const segment = dataWithEMAs.slice(startIdx, endIdx + 1);
        
        // Get significant points within this segment
        const segHighs = sigPoints.highs.filter(idx => idx >= startIdx && idx <= endIdx);
        const segLows = sigPoints.lows.filter(idx => idx >= startIdx && idx <= endIdx);
        
        if (segHighs.length < 2 || segLows.length < 2) {
            return null;
        }
        
        // Require at least 3 touches for a valid channel
        const totalTouches = segHighs.length + segLows.length;
        if (totalTouches < 3) {
            return null;
        }
        
        // Fit lines through highs and lows
        const highX = segHighs.map(idx => idx - startIdx + 1);
        const highY = segHighs.map(idx => dataWithEMAs[idx].high);
        const lowX = segLows.map(idx => idx - startIdx + 1);
        const lowY = segLows.map(idx => dataWithEMAs[idx].low);
        
        const upperFit = linearRegression(highX, highY);
        const lowerFit = linearRegression(lowX, lowY);
        
        if (isNaN(upperFit.slope) || isNaN(lowerFit.slope)) {
            return null;
        }
        
        // Check if slopes are similar
        if (Math.abs(upperFit.slope - lowerFit.slope) > 0.1) {
            return null;
        }
        
        // Calculate average R-squared
        const avgR2 = (upperFit.r2 + lowerFit.r2) / 2;
        
        // Check channel height
        const channelHeight = Math.abs(upperFit.intercept - lowerFit.intercept);
        if (channelHeight < minChannelHeight) {
            return null;
        }
        
        // Require stronger R-squared for shorter channels
        const minRequiredR2 = minR2 + (1 - ((endIdx - startIdx) / dataWithEMAs.length)) * 0.1;
        if (avgR2 < minRequiredR2) {
            return null;
        }
        
        // Check EMA alignment at the end of the channel
        const endEmaCheck = determineTrend(dataWithEMAs, endIdx);
        const emaTrend = endEmaCheck.trend;
        
        // Define slope threshold for channel type determination
        const slopeThreshold = 0.002;
        
        // Determine channel type primarily based on slope
        let channelType;
        
        // For significant slope (more than 1%), rely primarily on the slope
        const significantSlope = Math.abs(upperFit.slope) > 0.01;
        
        if (upperFit.slope > slopeThreshold) {
            // If slope is positive, classify as uptrend
            channelType = "U";  // Uptrend
            
            // Only reclassify as flat if slope is small and there are conflicting indicators
            if (significantSlope === false && 
                (emaTrend !== "UP" || dataWithEMAs[endIdx].close <= dataWithEMAs[startIdx].close)) {
                channelType = "F";  // Flat (conflicting signals with small slope)
            }
        } else if (upperFit.slope < -slopeThreshold) {
            // If slope is negative, classify as downtrend
            channelType = "D";  // Downtrend
            
            // Only reclassify as flat if slope is small and there are conflicting indicators
            if (significantSlope === false && 
                (emaTrend !== "DOWN" || dataWithEMAs[endIdx].close >= dataWithEMAs[startIdx].close)) {
                channelType = "F";  // Flat (conflicting signals with small slope)
            }
        } else {
            channelType = "F";  // Flat (very small slope)
        }
        
        return {
            upperFit,
            lowerFit,
            slope: upperFit.slope,
            r2: avgR2,
            touches: totalTouches,
            type: channelType
        };
    }
    
    // Find potential channels
    for (let i = 0; i < dataWithEMAs.length - minSegment; i++) {
        for (let j = i + minSegment; j < dataWithEMAs.length; j++) {
            const channel = fitChannel(i, j);
            
            if (channel) {
                // Calculate a freeze point that represents where the channel becomes stable
                // Typically this is about 2/3 into the channel length
                const freezePoint = Math.floor(i + (j - i) * 0.67);
                
                channels.push({
                    type: channel.type,
                    start: i,
                    end: j,
                    upper: channel.upperFit.intercept,
                    lower: channel.lowerFit.intercept,
                    slope: channel.slope,
                    r2: channel.r2,
                    extendedEnd: j,
                    freezePoint: freezePoint // Add the freeze point
                });
            }
        }
    }
    
    // Sort channels by R-squared value (quality)
    channels.sort((a, b) => b.r2 - a.r2);
    
    // Filter overlapping channels to keep only the best ones
    // Also implement channel freezing
    const filteredChannels = [];
    const usedIndices = new Set();
    const frozenChannels = new Map(); // To store frozen channels
    
    for (const channel of channels) {
        // Check if this channel significantly overlaps with any already selected channel
        let hasSignificantOverlap = false;
        
        for (let i = channel.start; i <= channel.end; i++) {
            if (usedIndices.has(i)) {
                hasSignificantOverlap = true;
                break;
            }
        }
        
        if (!hasSignificantOverlap) {
            // Add the channel to filtered channels
            filteredChannels.push(channel);
            
            // Mark indices as used, but also handle freezing
            for (let i = channel.start; i <= channel.end; i++) {
                usedIndices.add(i);
                
                // When we reach the freeze point, store this channel as frozen
                if (i === channel.freezePoint) {
                    frozenChannels.set(channel.freezePoint, {
                        type: channel.type,
                        upperIntercept: channel.upper,
                        lowerIntercept: channel.lower,
                        slope: channel.slope,
                        startIdx: channel.start
                    });
                }
            }
        }
    }
    
    // Process each channel to extend based on frozen data
    for (let channel of filteredChannels) {
        // Check if there are any channels that start after this channel's freeze point
        // that should be influenced by this frozen channel
        const latestIndex = dataWithEMAs.length - 1;
        
        // Extend the channel's end point if the freeze point has been reached
        if (channel.freezePoint <= channel.end) {
            // Mark the channel as frozen
            channel.isFrozen = true;
            
            // Extend the channel to the latest data point
            channel.extendedEnd = latestIndex;
        }
    }
    
    // Sort by start time for final result
    return filteredChannels.sort((a, b) => a.start - b.start);
}

/**
 * Detect transitions between channels
 * @param {Array} channels - Array of channel objects
 * @param {Array} data - Array of price data
 * @returns {Array} Array of transition objects
 */
function detectChannelChanges(channels, data) {
    if (!channels || channels.length < 2) {
        return [];
    }
    
    const changes = [];
    
    // Sort channels by start time
    channels.sort((a, b) => a.start - b.start);
    
    // Track positions where transitions were added
    const usedPositions = new Set();
    
    // First pass: detect transitions between consecutive channels
    for (let i = 1; i < channels.length; i++) {
        const prevChannel = channels[i - 1];
        const currChannel = channels[i];
        
        // Find the breakout point - use the start of the current channel
        const breakoutIdx = currChannel.start;
        
        // Calculate the previous channel's lines at the breakout point
        const timeDiff = breakoutIdx - prevChannel.start;
        const prevUpper = prevChannel.upper + prevChannel.slope * timeDiff;
        const prevLower = prevChannel.lower + prevChannel.slope * timeDiff;
        
        // Calculate the current channel's lines at its start
        const currUpper = currChannel.upper;
        const currLower = currChannel.lower;
        
        // Calculate strength based on slope change and R-squared
        const slopeChange = Math.abs(currChannel.slope - prevChannel.slope);
        const r2Avg = (currChannel.r2 + prevChannel.r2) / 2;
        const strength = slopeChange * r2Avg;
        
        // Get price at the transition point
        const transitionPrice = data[breakoutIdx].close;
        
        // Determine transition type based on channel types
        const fromType = prevChannel.type;
        const toType = currChannel.type;
        
        // Check if there's a gap between channels
        const isGap = prevChannel.end < currChannel.start - 1;
        
        // Determine where to display the transition label
        let displayPosition;
        if (toType === "U") {
            displayPosition = "top";
        } else if (toType === "D") {
            displayPosition = "bottom";
        } else if (fromType === "U") {
            displayPosition = "top";
        } else {
            displayPosition = "bottom";
        }
        
        // Add the channel change
        changes.push({
            position: breakoutIdx,
            fromType,
            toType,
            strength,
            priceLevel: transitionPrice,
            displayPosition,
            isGapTransition: isGap,
            fromSlope: prevChannel.slope * 100,
            toSlope: currChannel.slope * 100
        });
        
        usedPositions.add(breakoutIdx);
        
        // Disable gap transitions as they can show up in areas without channels
        // If you want to enable them, set this flag to true
        const enableGapTransitions = false;
        
        // If there's a gap between channels, add intermediate transitions (if enabled)
        if (enableGapTransitions && isGap && (prevChannel.end + 1) < (currChannel.start - 1)) {
            // Find a midpoint in the gap for the transition
            const gapMidpoint = Math.floor((prevChannel.end + currChannel.start) / 2);
            
            // Only add if not too close to existing transitions
            if (![...usedPositions].some(pos => Math.abs(gapMidpoint - pos) < 5)) {
                // Get price at the gap midpoint
                const gapPrice = data[gapMidpoint].close;
                
                // Add a transition at the gap midpoint
                changes.push({
                    position: gapMidpoint,
                    fromType,
                    toType,
                    strength: strength * 0.8,  // Slightly lower strength for gap transitions
                    priceLevel: gapPrice,
                    displayPosition,
                    isGapTransition: true,
                    fromSlope: prevChannel.slope * 100,
                    toSlope: currChannel.slope * 100
                });
                
                usedPositions.add(gapMidpoint);
            }
        }
    }
    
    // Sort changes by position
    return changes.sort((a, b) => a.position - b.position);
}

/**
 * Calculate Fibonacci retracement levels based on price data
 * @param {Array} data - Array of price objects with high and low properties
 * @returns {Object} Object containing Fibonacci levels
 */
function calculateFibonacci(data) {
    // Handle edge cases with empty data
    if (!data || data.length === 0) {
        return {
            "0%": 100,
            "23.6%": 94.72,
            "38.2%": 91.18,
            "50%": 88.5,
            "61.8%": 85.82,
            "78.6%": 82.28,
            "100%": 77
        };
    }
    
    // Calculate high and low safely
    let high, low;
    try {
        high = Math.max(...data.map(item => item.high));
        low = Math.min(...data.map(item => item.low));
    } catch (error) {
        console.error("Error calculating high/low:", error.message);
        high = 100;
        low = 77;
    }
    
    // Handle invalid values
    if (!isFinite(high) || isNaN(high)) high = 100;
    if (!isFinite(low) || isNaN(low)) low = 77;
    
    // Ensure high is greater than low
    if (high <= low) {
        // If high and low are identical or inverted, create artificial spread
        const meanVal = (high + low) / 2;
        high = meanVal * 1.15;  // 15% above mean
        low = meanVal * 0.85;   // 15% below mean
    }
    
    const diff = high - low;
    
    // Common Fibonacci levels: 0%, 23.6%, 38.2%, 50%, 61.8%, 78.6%, 100%
    const levels = {
        "0%": high,
        "23.6%": high - 0.236 * diff,
        "38.2%": high - 0.382 * diff,
        "50%": high - 0.5 * diff,
        "61.8%": high - 0.618 * diff,
        "78.6%": high - 0.786 * diff,
        "100%": low
    };
    
    return levels;
}

// Universal Module Definition (UMD) pattern
// This makes the code compatible with both Node.js and browser environments
if (typeof module !== 'undefined' && module.exports) {
    // Node.js environment
    module.exports = {
        linearRegression,
        findSignificantPoints,
        calculateEMAs,
        determineTrend,
        findChannels,
        detectChannelChanges,
        calculateFibonacci,
        // New technical indicators
        calculateRSI,
        calculateMACD,
        calculateBollingerBands,
        calculateATR
    };
}
// In browser, functions are already globally accessible