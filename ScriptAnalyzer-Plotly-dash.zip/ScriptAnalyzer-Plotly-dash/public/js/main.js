// Stock Analysis App - Frontend JavaScript

// Store chart object for later reference
let stockChart = null;
let lastZoomState = null;
let showChannels = false; // Default to hiding channels
let showFibLevels = true; // Default to showing Fibonacci levels
let showEMAs = false;     // Default to hiding EMAs
let showRSI = false;      // Default to hiding RSI
let showMACD = false;     // Default to hiding MACD
let showBB = false;       // Default to hiding Bollinger Bands
let showATR = false;      // Default to hiding ATR
let showChannelMarkers = false; // Hide channel markers (stars and diamonds) by default
let darkTheme = true;     // Default to dark theme

// Auto-refresh functionality
let autoRefreshEnabled = false;  // Auto-refresh state
let refreshTimer = null;         // Timer reference for auto-refresh
let nextRefreshTime = null;      // Next scheduled refresh time
let refreshInterval = 60000;     // Default refresh interval (60 seconds)

// Utility function to format date for display
function formatDate(dateString) {
    const options = { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
}

// Function to format date in Month/Day/Year format with time
function formatDateMDY(date) {
    const month = date.getMonth() + 1; // getMonth() is zero-based
    const day = date.getDate();
    const year = date.getFullYear();
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    
    return `${month}/${day}/${year} ${hours}:${minutes}`;
}

// Function to log messages to the console output area
function logMessage(message) {
    const timestamp = new Date().toLocaleTimeString();
    const consoleOutput = document.getElementById('consoleOutput');
    consoleOutput.innerHTML += `${timestamp}: ${message}\n`;
    consoleOutput.scrollTop = consoleOutput.scrollHeight;
}

// Helper function to draw channel lines on the chart
function createChannelTraces(dates, channelData, stockData, fibLevels) {
    if (!channelData || !channelData.length) return [];
    
    const traces = [];
    
    // Get Fibonacci 0% and 100% levels if available
    let fib0 = null;
    let fib100 = null;
    
    if (fibLevels) {
        fib0 = fibLevels["0%"];
        fib100 = fibLevels["100%"];
    }
    
    // Find next channel start points for each channel
    const nextChannelStartPoints = [];
    for (let i = 0; i < channelData.length; i++) {
        // Find the nearest next channel's start point that comes after this channel's freeze/end point
        let nextStartPoint = null;
        let nextStartDate = null;
        
        for (let j = 0; j < channelData.length; j++) {
            // Skip comparing the channel to itself
            if (i === j) continue;
            
            // For all channels (frozen or not), look for any channel that starts 
            // after this channel's start point (more restrictive criteria)
            if (channelData[j].start > channelData[i].start) {
                // If we haven't found a next channel yet, or if this channel starts earlier
                // than the current next channel, update the next channel
                if (nextStartPoint === null || channelData[j].start < nextStartPoint) {
                    nextStartPoint = channelData[j].start;
                    nextStartDate = dates[channelData[j].start];
                }
            }
        }
        
        nextChannelStartPoints[i] = { index: nextStartPoint, date: nextStartDate };
    }
    
    // Process each channel
    channelData.forEach((channel, index) => {
        // Calculate start and end dates for the channel
        const startDate = dates[channel.start];
        const endDate = dates[channel.end];
        const freezeDate = dates[channel.freezePoint];
        
        // Calculate color based on channel type
        let lineColor;
        if (channel.type === 'U') {
            lineColor = 'rgba(0, 180, 0, 0.8)';  // Green for uptrends
        } else if (channel.type === 'D') {
            lineColor = 'rgba(220, 0, 0, 0.8)';  // Red for downtrends
        } else {
            lineColor = 'rgba(100, 100, 100, 0.8)';  // Gray for flat/neutral
        }
        
        // Calculate end points based on whether the channel is frozen and if there's a next channel
        const nextChannelInfo = nextChannelStartPoints[index];
        
        // Determine the proper end date for this channel's display
        let displayEndDate;
        let displayEndOffset;
        
        if (channel.isFrozen) {
            // If there's a next channel, project only until that channel starts
            if (nextChannelInfo?.date) {
                displayEndDate = nextChannelInfo.date;
                displayEndOffset = (nextChannelInfo.index - channel.start);
            } else {
                // Otherwise, use the extended end or the chart end
                displayEndDate = dates[channel.extendedEnd] || dates[dates.length - 1];
                displayEndOffset = (channel.extendedEnd - channel.start);
            }
        } else {
            // For non-frozen channels, always respect the next channel start point,
            // and never project beyond the channel's own end point
            if (nextChannelInfo?.date) {
                // If there's a next channel, always limit projection to its start point
                displayEndDate = nextChannelInfo.date;
                displayEndOffset = (nextChannelInfo.index - channel.start);
            } else {
                // Otherwise, use this channel's actual end point (no projection)
                displayEndDate = endDate;
                displayEndOffset = (channel.end - channel.start);
            }
        }
        
        // For frozen channels, create two separate segments: established (solid) and projected (dotted)
        let upperTraces = [];
        
        if (channel.isFrozen) {
            // First segment - from start to freeze point (solid line)
            const freezeTimeDiff = channel.freezePoint - channel.start;
            const upperFreezeY = channel.upper + channel.slope * freezeTimeDiff;
            
            const upperEstablishedTrace = {
                x: [startDate, freezeDate],
                y: [channel.upper, upperFreezeY],
                mode: 'lines',
                name: `Channel ${index + 1} Upper (${channel.type}) - Established`,
                line: {
                    color: lineColor,
                    width: 3,
                    dash: 'solid'
                },
                hoverinfo: 'text',
                hovertext: `Channel ${index + 1} (${channel.type === 'U' ? 'Uptrend' : channel.type === 'D' ? 'Downtrend' : 'Flat'})
                        R²: ${channel.r2.toFixed(3)}
                        Slope: ${(channel.slope * 100).toFixed(2)}%
                        Status: Frozen (established)`,
                legendgroup: `channel-${index}`,
                showlegend: false
            };
            
            // Second segment - from freeze point to extended end (dotted line)
            // Use the original channel slope calculation for visualization consistency
            const originalUpperEndY = channel.upper + channel.slope * displayEndOffset;
            let upperExtendedEndY = originalUpperEndY;
            
            // Keep linear projections without applying Fibonacci constraints
            // This ensures channel projections continue in a straight line without bending
            
            const upperProjectedTrace = {
                x: [freezeDate, displayEndDate],
                y: [upperFreezeY, upperExtendedEndY],
                mode: 'lines',
                name: `Channel ${index + 1} Upper (${channel.type}) - Projected`,
                line: {
                    color: lineColor,
                    width: 2,
                    dash: 'dot'
                },
                hoverinfo: 'text',
                hovertext: `Channel ${index + 1} (${channel.type === 'U' ? 'Uptrend' : channel.type === 'D' ? 'Downtrend' : 'Flat'})
                        R²: ${channel.r2.toFixed(3)}
                        Slope: ${(channel.slope * 100).toFixed(2)}%
                        Status: Projected extension`,
                legendgroup: `channel-${index}`,
                showlegend: false
            };
            
            upperTraces.push(upperEstablishedTrace);
            upperTraces.push(upperProjectedTrace);
        } else {
            // For non-frozen channels, keep a single trace but apply constraints
            
            // Calculate the expected y value at display end using the channel's slope
            // Keep linear projections without applying Fibonacci constraints
            let upperEndY = channel.upper + channel.slope * displayEndOffset;
            
            const upperTrace = {
                x: [startDate, displayEndDate],
                y: [channel.upper, upperEndY],
                mode: 'lines',
                name: `Channel ${index + 1} Upper (${channel.type})`,
                line: {
                    color: lineColor,
                    width: 2,
                    dash: 'dot'
                },
                hoverinfo: 'text',
                hovertext: `Channel ${index + 1} (${channel.type === 'U' ? 'Uptrend' : channel.type === 'D' ? 'Downtrend' : 'Flat'})
                        R²: ${channel.r2.toFixed(3)}
                        Slope: ${(channel.slope * 100).toFixed(2)}%
                        Status: Active`,
                legendgroup: `channel-${index}`,
                showlegend: false
            };
            upperTraces.push(upperTrace);
        }
        
        // For frozen channels, create two separate segments for lower boundary: established (solid) and projected (dotted)
        let lowerTraces = [];
        
        if (channel.isFrozen) {
            // First segment - from start to freeze point (solid line)
            const freezeTimeDiff = channel.freezePoint - channel.start;
            const lowerFreezeY = channel.lower + channel.slope * freezeTimeDiff;
            
            const lowerEstablishedTrace = {
                x: [startDate, freezeDate],
                y: [channel.lower, lowerFreezeY],
                mode: 'lines',
                name: `Channel ${index + 1} Lower (${channel.type}) - Established`,
                line: {
                    color: lineColor,
                    width: 3,
                    dash: 'solid'
                },
                hoverinfo: 'text',
                hovertext: `Channel ${index + 1} (${channel.type === 'U' ? 'Uptrend' : channel.type === 'D' ? 'Downtrend' : 'Flat'})
                        R²: ${channel.r2.toFixed(3)}
                        Slope: ${(channel.slope * 100).toFixed(2)}%
                        Status: Frozen (established)`,
                legendgroup: `channel-${index}`,
                showlegend: false
            };
            
            // Second segment - from freeze point to extended end (dotted line)
            // Use the original channel slope calculation for visualization consistency
            const originalLowerEndY = channel.lower + channel.slope * displayEndOffset;
            let lowerExtendedEndY = originalLowerEndY;
            
            // Keep linear projections without applying Fibonacci constraints
            // This ensures channel projections continue in a straight line without bending
            
            const lowerProjectedTrace = {
                x: [freezeDate, displayEndDate],
                y: [lowerFreezeY, lowerExtendedEndY],
                mode: 'lines',
                name: `Channel ${index + 1} Lower (${channel.type}) - Projected`,
                line: {
                    color: lineColor,
                    width: 2,
                    dash: 'dot'
                },
                hoverinfo: 'text',
                hovertext: `Channel ${index + 1} (${channel.type === 'U' ? 'Uptrend' : channel.type === 'D' ? 'Downtrend' : 'Flat'})
                        R²: ${channel.r2.toFixed(3)}
                        Slope: ${(channel.slope * 100).toFixed(2)}%
                        Status: Projected extension`,
                legendgroup: `channel-${index}`,
                showlegend: false
            };
            
            lowerTraces.push(lowerEstablishedTrace);
            lowerTraces.push(lowerProjectedTrace);
        } else {
            // For non-frozen channels, keep a single trace but apply similar constraints as frozen channels
            
            // Calculate the expected y value at display end using the channel's slope
            // Keep linear projections without applying Fibonacci constraints
            let lowerEndY = channel.lower + channel.slope * displayEndOffset;
            
            const lowerTrace = {
                x: [startDate, displayEndDate],
                y: [channel.lower, lowerEndY],
                mode: 'lines',
                name: `Channel ${index + 1} Lower`,
                line: {
                    color: lineColor,
                    width: 2,
                    dash: 'dot'
                },
                hoverinfo: 'text',
                hovertext: `Channel ${index + 1} (${channel.type === 'U' ? 'Uptrend' : channel.type === 'D' ? 'Downtrend' : 'Flat'})
                        R²: ${channel.r2.toFixed(3)}
                        Slope: ${(channel.slope * 100).toFixed(2)}%
                        Status: Active`,
                legendgroup: `channel-${index}`,
                showlegend: false
            };
            lowerTraces.push(lowerTrace);
        }
        
        // Create freeze point marker (diamond shape)
        // Calculate the y-values at the freeze point
        const freezeTimeDiff = channel.freezePoint - channel.start;
        const upperFreezeY = channel.upper + channel.slope * freezeTimeDiff;
        const lowerFreezeY = channel.lower + channel.slope * freezeTimeDiff;
        
        // Create upper freeze point marker
        const upperFreezeMarker = {
            x: [freezeDate],
            y: [upperFreezeY],
            mode: 'markers',
            name: `Channel ${index + 1} Freeze Point Upper`,
            marker: {
                size: 10,
                color: lineColor,
                symbol: 'diamond',
                line: {
                    width: 2,
                    color: '#333'
                }
            },
            hoverinfo: 'text',
            hovertext: `Channel ${index + 1} Freeze Point
                        R²: ${channel.r2.toFixed(3)}
                        Established channel - future candles will not affect`,
            legendgroup: `channel-${index}`,
            showlegend: false
        };
        
        // Create lower freeze point marker
        const lowerFreezeMarker = {
            x: [freezeDate],
            y: [lowerFreezeY],
            mode: 'markers',
            name: `Channel ${index + 1} Freeze Point Lower`,
            marker: {
                size: 10,
                color: lineColor,
                symbol: 'diamond',
                line: {
                    width: 2,
                    color: '#333'
                }
            },
            hoverinfo: 'text',
            hovertext: `Channel ${index + 1} Freeze Point
                        R²: ${channel.r2.toFixed(3)}
                        Established channel - future candles will not affect`,
            legendgroup: `channel-${index}`,
            showlegend: false
        };
        
        // Create start point markers (asterisk shape) to mark where channel begins
        const upperStartValue = channel.upper;
        const lowerStartValue = channel.lower;
        
        // Create upper start point marker
        const upperStartMarker = {
            x: [startDate],
            y: [upperStartValue],
            mode: 'markers',
            name: `Channel ${index + 1} Start Point Upper`,
            marker: {
                size: 12,
                color: lineColor,
                symbol: 'star', // Asterisk/star marker
                line: {
                    width: 2,
                    color: '#333'
                }
            },
            hoverinfo: 'text',
            hovertext: `Channel ${index + 1} Starting Point
                        R²: ${channel.r2.toFixed(3)}
                        Channel formation begins here`,
            legendgroup: `channel-${index}`,
            showlegend: false
        };
        
        // Create lower start point marker
        const lowerStartMarker = {
            x: [startDate],
            y: [lowerStartValue],
            mode: 'markers',
            name: `Channel ${index + 1} Start Point Lower`,
            marker: {
                size: 12,
                color: lineColor,
                symbol: 'star', // Asterisk/star marker
                line: {
                    width: 2,
                    color: '#333'
                }
            },
            hoverinfo: 'text',
            hovertext: `Channel ${index + 1} Starting Point
                        R²: ${channel.r2.toFixed(3)}
                        Channel formation begins here`,
            legendgroup: `channel-${index}`,
            showlegend: false
        };

        // Add all traces
        // Add upper boundary traces (established and/or projected)
        upperTraces.forEach(trace => traces.push(trace));
        
        // Add lower boundary traces (established and/or projected)
        lowerTraces.forEach(trace => traces.push(trace));
        
        // Add start point markers for all channels (only if markers are enabled)
        if (showChannelMarkers) {
            traces.push(upperStartMarker);
            traces.push(lowerStartMarker);
        }
        
        // Add freeze point markers (only for frozen channels and if markers are enabled)
        if (channel.isFrozen && showChannelMarkers) {
            traces.push(upperFreezeMarker);
            traces.push(lowerFreezeMarker);
        }
    });
    
    return traces;
}

// Helper function to create transition markers
function createTransitionTraces(dates, transitionData, stockData) {
    if (!transitionData || !transitionData.length) return [];
    
    // Group transitions for better visualization
    const traces = [];
    
    // Create markers for transitions
    const markers = {
        x: [],
        y: [],
        mode: 'markers+text',
        name: 'Channel Transitions',
        marker: {
            size: 14,
            color: [],
            symbol: [], // We'll set this dynamically based on transition type
            line: {
                width: 2,
                color: '#333'
            }
        },
        text: [],
        textposition: [],
        hoverinfo: 'text',
        hovertext: []
    };
    
    transitionData.forEach(transition => {
        // Position and date
        const date = dates[transition.position];
        const price = transition.priceLevel;
        
        // Skip if date or price is undefined
        if (!date || price === undefined) return;
        
        // Add to markers trace
        markers.x.push(date);
        markers.y.push(price);
        
        // Determine color and symbol based on transition type
        let color;
        let symbol;
        let transitionDescription;
        
        if (transition.fromType === 'U' && transition.toType === 'D') {
            color = 'rgba(255, 80, 80, 0.9)';  // Red for down transitions
            symbol = 'triangle-down';          // Down-pointing triangle
            transitionDescription = 'Uptrend to Downtrend';
        } else if (transition.fromType === 'D' && transition.toType === 'U') {
            color = 'rgba(32, 208, 194, 0.9)';  // Teal for up transitions (#20D0C2)
            symbol = 'triangle-up';            // Up-pointing triangle
            transitionDescription = 'Downtrend to Uptrend';
        } else {
            color = 'rgba(150, 150, 150, 0.9)';  // Gray for other transitions
            symbol = 'circle';                  // Circle for other transitions
            transitionDescription = `${transition.fromType} to ${transition.toType}`;
        }
        
        markers.marker.color.push(color);
        markers.marker.symbol.push(symbol);
        
        // Create transition label text with more information
        const transitionText = `${transition.fromType}→${transition.toType}`;
        markers.text.push(transitionText);
        
        // Determine text position based on display position
        markers.textposition.push(transition.displayPosition === 'top' ? 'top center' : 'bottom center');
        
        // Create detailed hover text with more information
        markers.hovertext.push(
            `Transition: ${transitionDescription}
            Strength: ${transition.strength.toFixed(3)}
            Slope change: ${transition.fromSlope.toFixed(2)}% → ${transition.toSlope.toFixed(2)}%
            Price: ${transition.priceLevel.toFixed(2)}
            Channel Point Type: ${symbol === 'triangle-up' ? 'Triangle Up' : 
                                 symbol === 'triangle-down' ? 'Triangle Down' : 'Circle'}`
        );
    });
    
    // Only show transition markers if they are enabled
    if (markers.x.length > 0 && showChannelMarkers) {
        traces.push(markers);
    }
    
    return traces;
}

// Helper function to create Fibonacci level traces
// Function to create EMA traces
function createEMATraces(dates, data) {
    // Performance optimization: Early return if EMAs are not being displayed
    if (!showEMAs) return [];
    
    if (!data || !dates || !dates.length) return [];
    
    // Check if we need to calculate EMAs
    let hasAnyEMA = false;
    for (let i = 0; i < data.length; i++) {
        if (data[i] && (data[i].ema8 !== undefined || data[i].ema13 !== undefined || 
                        data[i].ema21 !== undefined || data[i].ema50 !== undefined)) {
            hasAnyEMA = true;
            break;
        }
    }
    
    // If EMAs don't exist in the data and we need them, calculate on-demand
    if (!hasAnyEMA) {
        console.log('Performance optimization: Lazy-loading EMA calculations');
        try {
            // Import the EMA calculation function if available in window scope
            if (typeof calculateEMAs === 'function') {
                data = calculateEMAs(data);
                // Check again if calculation succeeded
                hasAnyEMA = data[0] && (data[0].ema8 !== undefined || data[0].ema13 !== undefined || 
                               data[0].ema21 !== undefined || data[0].ema50 !== undefined);
            } else {
                console.warn('EMA calculation function not available');
                return [];
            }
        } catch (err) {
            console.error('Error calculating EMAs on demand:', err);
            return [];
        }
    }
    
    const traces = [];
    const emaColors = {
        'ema8': 'rgba(255, 0, 0, 0.6)',      // Red (more transparent)
        'ema13': 'rgba(255, 165, 0, 0.6)',   // Orange (more transparent)
        'ema21': 'rgba(32, 208, 194, 0.6)',  // Teal (more transparent) (#20D0C2)
        'ema50': 'rgba(0, 0, 255, 0.6)'      // Blue (more transparent)
    };
    
    // Optimize data structures for better performance
    const dataLength = data.length;
    
    // Create traces for each EMA type, using pre-allocation for better performance
    Object.keys(emaColors).forEach(emaType => {
        // Pre-count how many points we have for this EMA
        let pointCount = 0;
        for (let i = 0; i < dataLength; i++) {
            if (data[i] && data[i][emaType] !== undefined) {
                pointCount++;
            }
        }
        
        if (pointCount > 0) {
            // Pre-allocate arrays for better performance
            const x = new Array(pointCount);
            const y = new Array(pointCount);
            const hoverTexts = new Array(pointCount);
            
            // Fill arrays
            let index = 0;
            for (let i = 0; i < dataLength; i++) {
                if (data[i] && data[i][emaType] !== undefined) {
                    x[index] = dates[i];
                    y[index] = data[i][emaType];
                    hoverTexts[index] = `${emaType.toUpperCase()}: ${data[i][emaType].toFixed(2)}`;
                    index++;
                }
            }
            
            // Create a trace for the EMA
            const emaTrace = {
                x: x,
                y: y,
                mode: 'lines',
                name: emaType.toUpperCase(),
                line: {
                    color: emaColors[emaType],
                    width: 1.5,
                    dash: 'dash'  // Changed to dashed lines for less visual distraction
                },
                hoverinfo: 'text',
                hovertext: hoverTexts,
                visible: true
            };
            
            traces.push(emaTrace);
        }
    });
    
    return traces;
}

function createFibonacciTraces(dates, fibLevels) {
    if (!fibLevels) return [];
    
    const traces = [];
    const startDate = dates[0];
    const endDate = dates[dates.length - 1];
    
    // Define colors for different Fibonacci levels
    const fibColors = {
        "0%": "rgba(255, 0, 0, 0.7)",      // Red
        "23.6%": "rgba(255, 165, 0, 0.7)", // Orange
        "38.2%": "rgba(255, 255, 0, 0.7)", // Yellow
        "50%": "rgba(32, 208, 194, 0.7)",  // Teal (#20D0C2)
        "61.8%": "rgba(0, 0, 255, 0.7)",   // Blue
        "78.6%": "rgba(75, 0, 130, 0.7)",  // Indigo
        "100%": "rgba(238, 130, 238, 0.7)" // Violet
    };
    
    // Create a trace for each Fibonacci level
    for (const [level, value] of Object.entries(fibLevels)) {
        // Create the line trace
        const trace = {
            x: [startDate, endDate],
            y: [value, value],
            mode: 'lines',
            name: `Fib ${level}`,
            line: {
                color: fibColors[level] || "rgba(150, 150, 150, 0.7)",
                width: level === "0%" || level === "100%" ? 2.5 : 1.5,  // Make 0% and 100% lines thicker
                dash: 'dash'
            },
            hoverinfo: 'text',
            hovertext: `Fibonacci ${level} level: ${value.toFixed(2)}`,
            showlegend: false, // Hide from legend
            xaxis: 'x',
            yaxis: 'y'
        };
        
        traces.push(trace);
        
        // Add text annotations for all Fibonacci levels on the left side
        // Create a text label at the left edge of the chart
        const textTrace = {
            x: [startDate],
            y: [value],
            mode: 'text',
            text: [`Fib ${level}: ${value.toFixed(2)}`], // Include the actual value
            textposition: 'left',
            textfont: {
                family: 'Arial, sans-serif',
                size: 10,
                color: fibColors[level]
            },
            hoverinfo: 'none',
            showlegend: false,
            xaxis: 'x',
            yaxis: 'y'
        };
        
        traces.push(textTrace);
    }
    
    return traces;
}

// Helper function to create RSI traces
function createRSITraces(dates, data) {
    // Performance optimization: Early return if RSI is not being displayed
    if (!showRSI) return [];
    
    // Check for first valid RSI value instead of checking at index 0
    // because RSI values may be undefined for initial data points
    let hasRSI = false;
    for (let i = 0; i < data.length; i++) {
        if (data[i] && data[i].rsi !== undefined) {
            hasRSI = true;
            break;
        }
    }
    
    // If RSI doesn't exist in the data and we need it, calculate it on-demand
    if (!hasRSI) {
        console.log('Performance optimization: Lazy-loading RSI calculation');
        try {
            // Import the RSI calculation function if available in window scope
            if (typeof calculateRSI === 'function') {
                data = calculateRSI(data, 14);
                // Check again if RSI calculation succeeded
                hasRSI = data[0] && data[0].rsi !== undefined;
            } else {
                console.warn('RSI calculation function not available');
                return [];
            }
        } catch (err) {
            console.error('Error calculating RSI on demand:', err);
            return [];
        }
    }
    
    // Final validation check
    if (!data || !data.length || !hasRSI) return [];
    
    // Optimize array creation for performance
    const dataLength = data.length;
    const rsiValues = new Array(dataLength);
    
    for (let i = 0; i < dataLength; i++) {
        rsiValues[i] = data[i].rsi;
    }
    
    // Main RSI line
    const rsiTrace = {
        x: dates,
        y: rsiValues,
        type: 'scatter',
        mode: 'lines',
        name: 'RSI (14)',
        line: {
            color: 'rgba(32, 208, 194, 1)',  // Teal (#20D0C2) - primary color for RSI line
            width: 2
        },
        yaxis: 'y3', // RSI will be on a separate y-axis
        showlegend: false
    };
    
    // Overbought line (70)
    const overboughtTrace = {
        x: dates,
        y: Array(dates.length).fill(70),
        type: 'scatter',
        mode: 'lines',
        name: 'Overbought (70)',
        line: {
            color: 'rgba(184, 80, 66, 0.7)',  // Brownish-red (#B85042) for overbought line
            width: 1,
            dash: 'dash'
        },
        yaxis: 'y3',
        showlegend: false
    };
    
    // Oversold line (30)
    const oversoldTrace = {
        x: dates,
        y: Array(dates.length).fill(30),
        type: 'scatter',
        mode: 'lines',
        name: 'Oversold (30)',
        line: {
            color: 'rgba(32, 208, 194, 0.7)', // Teal (#20D0C2) - lighter for oversold line
            width: 1,
            dash: 'dash'
        },
        yaxis: 'y3',
        showlegend: false
    };
    
    // Neutral line (50)
    const neutralTrace = {
        x: dates,
        y: Array(dates.length).fill(50),
        type: 'scatter',
        mode: 'lines',
        name: 'Neutral (50)',
        line: {
            color: 'rgba(150, 150, 150, 0.5)',  // Light gray for neutral line
            width: 1,
            dash: 'dot'
        },
        yaxis: 'y3',
        showlegend: false
    };
    
    return [rsiTrace, overboughtTrace, oversoldTrace, neutralTrace];
}

// Helper function to create MACD traces
function createMACDTraces(dates, data) {
    // Performance optimization: Early return if MACD is not being displayed
    if (!showMACD) return [];
    
    // Check for first valid MACD value instead of checking at index 0
    // because MACD values may be undefined for initial data points
    let hasMacd = false;
    for (let i = 0; i < data.length; i++) {
        if (data[i] && data[i].macd !== undefined) {
            hasMacd = true;
            break;
        }
    }
    
    // If MACD doesn't exist in the data and we need it, calculate it on-demand
    if (!hasMacd) {
        console.log('Performance optimization: Lazy-loading MACD calculation');
        try {
            // Import the MACD calculation function if available in window scope
            if (typeof calculateMACD === 'function') {
                data = calculateMACD(data, {
                    fastPeriod: 12,
                    slowPeriod: 26,
                    signalPeriod: 9
                });
                // Check again if MACD calculation succeeded
                hasMacd = data[0] && data[0].macd !== undefined;
            } else {
                console.warn('MACD calculation function not available');
                return [];
            }
        } catch (err) {
            console.error('Error calculating MACD on demand:', err);
            return [];
        }
    }
    
    // Final validation check
    if (!data || !data.length || !hasMacd) return [];
    
    // Optimize array creation for performance
    const dataLength = data.length;
    const macdValues = new Array(dataLength);
    const signalValues = new Array(dataLength);
    const histogramValues = new Array(dataLength);
    
    for (let i = 0; i < dataLength; i++) {
        macdValues[i] = data[i].macd;
        signalValues[i] = data[i].macdSignal;
        histogramValues[i] = data[i].macdHistogram;
    }
    
    // MACD line
    const macdTrace = {
        x: dates,
        y: macdValues,
        type: 'scatter',
        mode: 'lines',
        name: 'MACD Line',
        line: {
            color: 'rgba(32, 208, 194, 0.9)', // Teal (#20D0C2) for MACD line
            width: 2
        },
        yaxis: 'y4', // MACD will be on a separate y-axis
        showlegend: false
    };
    
    // Signal line
    const signalTrace = {
        x: dates,
        y: signalValues,
        type: 'scatter',
        mode: 'lines',
        name: 'Signal Line',
        line: {
            color: 'rgba(184, 80, 66, 0.9)', // Brownish-red (#B85042) for signal line
            width: 2
        },
        yaxis: 'y4',
        showlegend: false
    };
    
    // Histogram
    const histogramColors = histogramValues.map(value => 
        value >= 0 ? 'rgba(32, 208, 194, 0.6)' : 'rgba(184, 80, 66, 0.6)' // Teal for positive (#20D0C2), brownish-red for negative (#B85042)
    );
    
    const histogramTrace = {
        x: dates,
        y: histogramValues,
        type: 'bar',
        name: 'MACD Histogram',
        marker: {
            color: histogramColors
        },
        yaxis: 'y4',
        showlegend: false
    };
    
    return [macdTrace, signalTrace, histogramTrace];
}

// Helper function to create Bollinger Bands traces
function createBollingerBandTraces(dates, data) {
    // Performance optimization: Early return if Bollinger Bands are not being displayed
    if (!showBB) return [];
    
    // Check for first valid Bollinger Band value
    let hasBB = false;
    for (let i = 0; i < data.length; i++) {
        if (data[i] && data[i].bollingerMiddle !== undefined) {
            hasBB = true;
            break;
        }
    }
    
    // If Bollinger Bands don't exist in the data and we need them, calculate on-demand
    if (!hasBB) {
        console.log('Performance optimization: Lazy-loading Bollinger Bands calculation');
        try {
            // Import the BB calculation function if available in window scope
            if (typeof calculateBollingerBands === 'function') {
                data = calculateBollingerBands(data, 20, 2);
                // Check again if calculation succeeded
                hasBB = data[0] && data[0].bollingerMiddle !== undefined;
            } else {
                console.warn('Bollinger Bands calculation function not available');
                return [];
            }
        } catch (err) {
            console.error('Error calculating Bollinger Bands on demand:', err);
            return [];
        }
    }
    
    // Final validation check
    if (!data || !data.length || !hasBB) return [];
    
    // Optimize array creation for performance
    const dataLength = data.length;
    const middleValues = new Array(dataLength);
    const upperValues = new Array(dataLength);
    const lowerValues = new Array(dataLength);
    
    for (let i = 0; i < dataLength; i++) {
        middleValues[i] = data[i].bollingerMiddle;
        upperValues[i] = data[i].bollingerUpper;
        lowerValues[i] = data[i].bollingerLower;
    }
    
    // Upper band
    const upperTrace = {
        x: dates,
        y: upperValues,
        type: 'scatter',
        mode: 'lines',
        name: 'BB Upper (2σ)',
        line: {
            color: 'rgba(32, 208, 194, 0.7)', // Teal (#20D0C2) for upper band
            width: 1
        },
        fill: 'tonexty',
        fillcolor: 'rgba(32, 208, 194, 0.1)', // Very light teal fill
        showlegend: false
    };
    
    // Middle band (20-day SMA)
    const middleTrace = {
        x: dates,
        y: middleValues,
        type: 'scatter',
        mode: 'lines',
        name: 'BB Middle (SMA 20)',
        line: {
            color: 'rgba(32, 208, 194, 0.9)', // Stronger teal (#20D0C2) for middle band
            width: 1,
            dash: 'dash'
        },
        showlegend: false
    };
    
    // Lower band
    const lowerTrace = {
        x: dates,
        y: lowerValues,
        type: 'scatter',
        mode: 'lines',
        name: 'BB Lower (2σ)',
        line: {
            color: 'rgba(32, 208, 194, 0.7)', // Teal (#20D0C2) for lower band
            width: 1
        },
        fill: 'tonexty',
        fillcolor: 'rgba(32, 208, 194, 0.1)', // Very light teal fill
        showlegend: false
    };
    
    return [upperTrace, middleTrace, lowerTrace];
}

// Helper function to create ATR traces
function createATRTraces(dates, data) {
    // Performance optimization: Early return if ATR is not being displayed
    if (!showATR) return [];
    
    // Check for first valid ATR value
    let hasATR = false;
    for (let i = 0; i < data.length; i++) {
        if (data[i] && data[i].atr !== undefined) {
            hasATR = true;
            break;
        }
    }
    
    // If ATR doesn't exist in the data and we need it, calculate on-demand
    if (!hasATR) {
        console.log('Performance optimization: Lazy-loading ATR calculation');
        try {
            // Import the ATR calculation function if available in window scope
            if (typeof calculateATR === 'function') {
                data = calculateATR(data, 14);
                // Check again if calculation succeeded
                hasATR = data[0] && data[0].atr !== undefined;
            } else {
                console.warn('ATR calculation function not available');
                return [];
            }
        } catch (err) {
            console.error('Error calculating ATR on demand:', err);
            return [];
        }
    }
    
    // Final validation check
    if (!data || !data.length || !hasATR) return [];
    
    // Optimize array creation for performance
    const dataLength = data.length;
    const atrValues = new Array(dataLength);
    
    for (let i = 0; i < dataLength; i++) {
        atrValues[i] = data[i].atr;
    }
    
    // ATR line
    const atrTrace = {
        x: dates,
        y: atrValues,
        type: 'scatter',
        mode: 'lines',
        name: 'ATR (14)',
        line: {
            color: 'rgba(184, 80, 66, 0.9)', // Brownish-red (#B85042) for ATR
            width: 2
        },
        yaxis: 'y5', // ATR will be on a separate y-axis
        showlegend: false
    };
    
    return [atrTrace];
}

// Helper function to create hover points that show channel values at each candle
function createChannelValueHoverPoints(dates, channelData, stockData) {
    if (!channelData || !channelData.length || !stockData || !stockData.length) return [];
    
    const traces = [];
    
    // Helper function to calculate angle from slope in degrees
    function calculateAngleFromSlope(slope) {
        // Math.atan() gives angle in radians, convert to degrees
        return (Math.atan(slope) * 180 / Math.PI).toFixed(2);
    }
    
    // For each date/candle in the dataset
    stockData.forEach((dataPoint, dateIndex) => {
        // Skip points that don't have a date
        if (!dates[dateIndex]) return;
        
        // Store which channels are active at this point
        const activeChannels = [];
        // Store channels with projections at this point
        const projectedChannels = [];
        
        // Check each channel
        channelData.forEach((channel, channelIndex) => {
            // If this date is within the channel's date range (active channel)
            if (dateIndex >= channel.start && dateIndex <= channel.end) {
                activeChannels.push({
                    channelIndex,
                    channel,
                    dateOffset: dateIndex - channel.start,
                    isProjection: false
                });
            } 
            // Check if this date is in a projected part of a frozen channel
            else if (channel.isFrozen && dateIndex > channel.end && dateIndex <= channel.extendedEnd) {
                // Always show frozen channel projections regardless of future channels
                // This ensures frozen channel projections are always visible
                projectedChannels.push({
                    channelIndex,
                    channel,
                    dateOffset: dateIndex - channel.start,
                    isProjection: true
                });
            }
        });
        
        // Always show both active channels and projections
        // This ensures frozen channel projections are visible even when overlapping with active channels
        let displayChannels = [...activeChannels, ...projectedChannels];
        
        // If no channels are active or projected at this point, skip
        if (displayChannels.length === 0) return;
        
        // Instead of showing all channels at once, we'll create separate hover points for each channel
        // This way, hovering near a specific channel line will only show that channel's info
        
        // First, add a basic hover point with just date and price (for areas with no channels)
        const baseHoverPoint = {
            x: [dates[dateIndex]],
            y: [dataPoint.close], // Use close price as the y position
            mode: 'markers',
            marker: {
                size: 1,
                color: 'rgba(0,0,0,0)'  // Invisible marker
            },
            hoverinfo: 'text',
            hovertext: `Date: ${dates[dateIndex].toLocaleString()}<br>Price: ${dataPoint.close.toFixed(2)}`,
            showlegend: false
        };
        traces.push(baseHoverPoint);
        
        // Create individual hover points for each active channel
        if (activeChannels.length > 0) {
            activeChannels.forEach(({channel, channelIndex, dateOffset}) => {
                // Calculate the upper and lower channel values at this point
                const upperValue = channel.upper + channel.slope * dateOffset;
                const lowerValue = channel.lower + channel.slope * dateOffset;
                
                // Determine channel type text
                let channelType;
                if (channel.type === 'U') channelType = 'Uptrend';
                else if (channel.type === 'D') channelType = 'Downtrend';
                else channelType = 'Flat';
                
                // Calculate angle from slope
                const angleInDegrees = calculateAngleFromSlope(channel.slope);
                
                // Create hover point for upper boundary of this channel
                const upperHoverPoint = {
                    x: [dates[dateIndex]],
                    y: [upperValue], // Locate at the upper channel boundary
                    mode: 'markers',
                    marker: {
                        size: 1,
                        color: 'rgba(0,0,0,0)'  // Invisible marker
                    },
                    hoverinfo: 'text',
                    hovertext: `Date: ${dates[dateIndex].toLocaleString()}<br>` +
                               `Channel ${channelIndex + 1} (${channelType}):<br>` +
                               `- Upper: ${upperValue.toFixed(2)}<br>` +
                               `- Lower: ${lowerValue.toFixed(2)}<br>` +
                               `- Slope: ${(channel.slope * 100).toFixed(2)}%<br>` +
                               `- Angle: ${angleInDegrees}°`,
                    showlegend: false
                };
                
                // Create hover point for lower boundary of this channel
                const lowerHoverPoint = {
                    x: [dates[dateIndex]],
                    y: [lowerValue], // Locate at the lower channel boundary
                    mode: 'markers',
                    marker: {
                        size: 1,
                        color: 'rgba(0,0,0,0)'  // Invisible marker
                    },
                    hoverinfo: 'text',
                    hovertext: `Date: ${dates[dateIndex].toLocaleString()}<br>` +
                               `Channel ${channelIndex + 1} (${channelType}):<br>` +
                               `- Upper: ${upperValue.toFixed(2)}<br>` +
                               `- Lower: ${lowerValue.toFixed(2)}<br>` +
                               `- Slope: ${(channel.slope * 100).toFixed(2)}%<br>` +
                               `- Angle: ${angleInDegrees}°`,
                    showlegend: false
                };
                
                traces.push(upperHoverPoint);
                traces.push(lowerHoverPoint);
            });
        }
        
        // Create individual hover points for each projected channel
        if (projectedChannels.length > 0) {
            projectedChannels.forEach(({channel, channelIndex, dateOffset}) => {
                // Calculate the upper and lower channel values at this projected point
                const upperValue = channel.upper + channel.slope * dateOffset;
                const lowerValue = channel.lower + channel.slope * dateOffset;
                
                // Get channel type text
                let channelType;
                if (channel.type === 'U') channelType = 'Uptrend';
                else if (channel.type === 'D') channelType = 'Downtrend';
                else channelType = 'Flat';
                
                // Calculate angle from slope
                const angleInDegrees = calculateAngleFromSlope(channel.slope);
                
                // Create hover point for upper boundary of this projected channel
                const upperHoverPoint = {
                    x: [dates[dateIndex]],
                    y: [upperValue], // Locate at the upper channel boundary
                    mode: 'markers',
                    marker: {
                        size: 1,
                        color: 'rgba(0,0,0,0)'  // Invisible marker
                    },
                    hoverinfo: 'text',
                    hovertext: `Date: ${dates[dateIndex].toLocaleString()}<br>` +
                               `Channel ${channelIndex + 1} (${channelType}) [Projected]:<br>` +
                               `- Upper: ${upperValue.toFixed(2)}<br>` +
                               `- Lower: ${lowerValue.toFixed(2)}<br>` +
                               `- Slope: ${(channel.slope * 100).toFixed(2)}%<br>` +
                               `- Angle: ${angleInDegrees}°`,
                    showlegend: false
                };
                
                // Create hover point for lower boundary of this projected channel
                const lowerHoverPoint = {
                    x: [dates[dateIndex]],
                    y: [lowerValue], // Locate at the lower channel boundary
                    mode: 'markers',
                    marker: {
                        size: 1,
                        color: 'rgba(0,0,0,0)'  // Invisible marker
                    },
                    hoverinfo: 'text',
                    hovertext: `Date: ${dates[dateIndex].toLocaleString()}<br>` +
                               `Channel ${channelIndex + 1} (${channelType}) [Projected]:<br>` +
                               `- Upper: ${upperValue.toFixed(2)}<br>` +
                               `- Lower: ${lowerValue.toFixed(2)}<br>` +
                               `- Slope: ${(channel.slope * 100).toFixed(2)}%<br>` +
                               `- Angle: ${angleInDegrees}°`,
                    showlegend: false
                };
                
                traces.push(upperHoverPoint);
                traces.push(lowerHoverPoint);
            });
        }
    });
    
    return traces;
}

// Function to create a stock chart using Plotly.js
// Function to clear any existing backtest results
function clearBacktestResults() {
    // Instead of hiding, show with an empty state message
    const container = document.getElementById('backtestResults');
    if (container) {
        container.classList.remove('d-none');
        
        // Create empty state content
        container.innerHTML = `
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-history me-2"></i>Backtest Results</h5>
            </div>
            <div class="card-body">
                <div class="text-center p-3">
                    <i class="fas fa-chart-line text-muted" style="font-size: 2rem;"></i>
                    <p class="mt-3 text-muted">No backtest results available yet. Click "Run Backtest" after analyzing a stock to see results here.</p>
                </div>
                <div class="row mt-3">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Type</th>
                                        <th>Entry</th>
                                        <th>Price</th>
                                        <th>Exit</th>
                                        <th>Price</th>
                                        <th>P/L</th>
                                        <th>R/R</th>
                                        <th>Stop Hit</th>
                                        <th>Reason</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td colspan="9" class="text-center text-muted">No trades found</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    // Clear the backtest input fields
    const startPointInput = document.getElementById('backtestStartPoint');
    const endPointInput = document.getElementById('backtestEndPoint');
    if (startPointInput) startPointInput.value = '';
    if (endPointInput) endPointInput.value = '';
    
    // Re-create the chart to remove backtest markers
    if (window.currentStockData) {
        createStockChart(window.currentStockData.data, window.currentStockData);
    }
}

// Function to calculate and display trade scores for current candle
function calculateTradeScores(data, allData) {
    if (!data || data.length === 0 || !allData.channels || !allData.fibLevels) {
        // Clear any existing scores if data is not available
        document.getElementById('longScoreBar').style.width = '0%';
        document.getElementById('longScoreBar').textContent = '0%';
        document.getElementById('shortScoreBar').style.width = '0%';
        document.getElementById('shortScoreBar').textContent = '0%';
        document.getElementById('longTradeDetails').textContent = 'No data available for analysis';
        document.getElementById('shortTradeDetails').textContent = 'No data available for analysis';
        return;
    }

    // Get the most recent candle for analysis
    const currentCandleIdx = data.length - 1;
    
    // Calculate scores for current candle
    const longScore = calculateLongTradeScore(
        data,                // Price data
        currentCandleIdx,    // Index of current candle
        allData.fibLevels,   // Fibonacci levels
        allData.channels,    // Price channels
        allData.emas,        // EMAs
        0.005                // Default tolerance
    );
    
    const shortScore = calculateShortTradeScore(
        data,                // Price data
        currentCandleIdx,    // Index of current candle
        allData.fibLevels,   // Fibonacci levels
        allData.channels,    // Price channels
        allData.emas,        // EMAs
        0.005                // Default tolerance
    );
    
    // Update UI with scores
    // Long score
    document.getElementById('longScoreBar').style.width = `${longScore.score}%`;
    document.getElementById('longScoreBar').textContent = `${longScore.score}%`;
    document.getElementById('longScoreBar').setAttribute('aria-valuenow', longScore.score);
    
    // Set color based on score and validity
    const longScoreBar = document.getElementById('longScoreBar');
    if (longScore.valid) {
        // Valid trades are always green (only occurs with score >= 90 at channel support)
        longScoreBar.className = 'progress-bar bg-success';
    } else if (longScore.score >= 90) {
        // High scores but not at channel support - yellow
        longScoreBar.className = 'progress-bar bg-warning';
    } else if (longScore.score >= 70) {
        // Moderate scores - light warning color
        longScoreBar.className = 'progress-bar bg-info';
    } else {
        // Low scores - gray
        longScoreBar.className = 'progress-bar bg-secondary';
    }
    
    // Long score details
    let longDetails = `<strong>${longScore.message}</strong><br>`;
    if (longScore.details.notes && longScore.details.notes.length > 0) {
        // Only show top 3 most important details to avoid cluttering
        const topNotes = longScore.details.notes.slice(0, 3);
        longDetails += topNotes.map(note => `• ${note}`).join('<br>');
    }
    document.getElementById('longTradeDetails').innerHTML = longDetails;
    
    // Short score
    document.getElementById('shortScoreBar').style.width = `${shortScore.score}%`;
    document.getElementById('shortScoreBar').textContent = `${shortScore.score}%`;
    document.getElementById('shortScoreBar').setAttribute('aria-valuenow', shortScore.score);
    
    // Set color based on score and validity
    const shortScoreBar = document.getElementById('shortScoreBar');
    if (shortScore.valid) {
        // Valid trades are always red (only occurs with score >= 90 at channel resistance)
        shortScoreBar.className = 'progress-bar bg-danger';
    } else if (shortScore.score >= 90) {
        // High scores but not at channel resistance - yellow
        shortScoreBar.className = 'progress-bar bg-warning';
    } else if (shortScore.score >= 70) {
        // Moderate scores - light warning color
        shortScoreBar.className = 'progress-bar bg-info';
    } else {
        // Low scores - gray
        shortScoreBar.className = 'progress-bar bg-secondary';
    }
    
    // Short score details
    let shortDetails = `<strong>${shortScore.message}</strong><br>`;
    if (shortScore.details.notes && shortScore.details.notes.length > 0) {
        // Only show top 3 most important details to avoid cluttering
        const topNotes = shortScore.details.notes.slice(0, 3);
        shortDetails += topNotes.map(note => `• ${note}`).join('<br>');
    }
    document.getElementById('shortTradeDetails').innerHTML = shortDetails;
    
    // Log trade signals for debugging
    if (longScore.valid) {
        logMessage(`LONG TRADE SIGNAL: Score ${longScore.score}% - ${longScore.message}`);
    }
    if (shortScore.valid) {
        logMessage(`SHORT TRADE SIGNAL: Score ${shortScore.score}% - ${shortScore.message}`);
    }
}

// Function to run backtesting on historical data
function runBacktest(data, allData) {
    // Make sure we have data to analyze
    if (!data || data.length < 10 || !allData.channels || !allData.fibLevels) {
        logMessage("Error: Not enough data for backtesting");
        return null;
    }
    
    // Get optional start point for backtesting from UI
    const startPointInput = document.getElementById('backtestStartPoint');
    const endPointInput = document.getElementById('backtestEndPoint');
    const minCandles = 21; // Minimum candles needed for proper analysis (largest EMA period)
    let startPoint = minCandles; // Default to minimum required candles
    let endPoint = data.length - 1; // Default to last candle
    
    // Set start point from input if provided
    if (startPointInput && startPointInput.value.trim()) {
        // Parse user input and apply constraints
        const userStartPoint = parseInt(startPointInput.value.trim());
        if (!isNaN(userStartPoint)) {
            // Ensure start point is at least minCandles and within data range
            startPoint = Math.max(minCandles, Math.min(userStartPoint, data.length - 1));
            logMessage(`Starting backtest from candle index ${startPoint} (user specified)`);
        }
    } else {
        logMessage(`Starting backtest from default position (candle index ${startPoint})`);
    }
    
    // Set end point from input if provided
    if (endPointInput && endPointInput.value.trim()) {
        // Parse user input and apply constraints
        const userEndPoint = parseInt(endPointInput.value.trim());
        if (!isNaN(userEndPoint)) {
            // Ensure end point is after start point and within data range
            endPoint = Math.max(startPoint + 1, Math.min(userEndPoint, data.length - 1));
            logMessage(`Ending backtest at candle index ${endPoint} (user specified)`);
        }
    } else {
        logMessage(`Ending backtest at default position (candle index ${endPoint})`);
    }
    
    logMessage(`Analyzing ${endPoint - startPoint + 1} historical candles sequentially...`);
    
    // Containers for backtest results
    const longSignals = [];
    const shortSignals = [];
    const backTestResults = {
        longSignals: [],
        shortSignals: [],
        longTrades: [],
        shortTrades: [],
        performance: {
            wins: 0,
            losses: 0,
            breakeven: 0,
            totalReturn: 0,
            averageReturn: 0,
            maxDrawdown: 0
        }
    };
    
    // Create a limited dataset for visualization up to the end candle
    const limitedData = endPoint < data.length - 1 ? data.slice(0, endPoint + 1) : data;
    const limitedAllData = {
        ...allData,
        data: limitedData,
        symbol: allData.symbol // Ensure symbol is preserved
    };
    
    // Update chart with limited data
    createStockChart(limitedData, limitedAllData);
    
    // Process one candle at a time starting from our specified point up to the end point
    for (let i = startPoint; i <= endPoint; i++) {
        // Calculate long score for this historical candle
        const longScore = calculateLongTradeScore(
            data,
            i,              // Historical candle index
            allData.fibLevels,
            allData.channels,
            allData.emas,
            0.005
        );
        
        // Calculate short score for this historical candle
        const shortScore = calculateShortTradeScore(
            data,
            i,              // Historical candle index
            allData.fibLevels,
            allData.channels,
            allData.emas,
            0.005
        );
        
        // Record only high-quality signals with score >= 90 that are valid
        // (valid means they're at channel support/resistance levels)
        if (longScore.valid && longScore.score >= 90) {
            longSignals.push({
                index: i,
                price: data[i].close,
                date: new Date(data[i].date),
                score: longScore.score,
                message: longScore.message
            });
        }
        
        if (shortScore.valid && shortScore.score >= 90) {
            shortSignals.push({
                index: i,
                price: data[i].close,
                date: new Date(data[i].date),
                score: shortScore.score,
                message: shortScore.message
            });
        }
    }
    
    // Simulate trades from signals with sequential processing
    const simulateTrades = (signals, isLong) => {
        const trades = [];
        const stopLossPercent = 0.02; // 2% stop loss
        const takeProfitPercent = 0.04; // 4% take profit
        const maxBarsInTrade = 15; // Maximum bars to hold a trade
        
        // Sort signals by index to ensure chronological order
        const sortedSignals = [...signals].sort((a, b) => a.index - b.index);
        
        // Keep track of active trades to simulate real-world constraints
        let activeTrades = [];
        // Maximum simultaneous trades allowed
        const maxSimultaneousTrades = 3;
        
        // Process one candle at a time sequentially from start to finish
        for (let currentCandle = startPoint; currentCandle <= endPoint; currentCandle++) {
            logMessage(`Processing candle ${currentCandle} of ${endPoint} for ${isLong ? 'LONG' : 'SHORT'} trades...`, false);
            
            // 1. Check for signals at the current candle
            const signalsAtCandle = sortedSignals.filter(s => s.index === currentCandle);
            
            // 2. Process new signals at current candle (enter new trades)
            signalsAtCandle.forEach(signal => {
                // Skip if we're already at max trades or too close to end of data
                if (activeTrades.length >= maxSimultaneousTrades || signal.index >= data.length - 5) return;
                
                const entry = data[signal.index].close;
                const stopLoss = isLong ? entry * (1 - stopLossPercent) : entry * (1 + stopLossPercent);
                const takeProfit = isLong ? entry * (1 + takeProfitPercent) : entry * (1 - takeProfitPercent);
                
                // Add to active trades
                activeTrades.push({
                    signal,
                    entry,
                    stopLoss,
                    takeProfit,
                    startedAt: currentCandle,
                    barsInTrade: 0
                });
            });
            
            // 3. Update and check exit conditions for existing trades
            const remainingTrades = [];
            
            for (const trade of activeTrades) {
                // Skip if this is the entry candle (no price action yet)
                if (trade.startedAt === currentCandle) {
                    remainingTrades.push(trade);
                    continue;
                }
                
                trade.barsInTrade++;
                
                // Current candle's price action
                const high = data[currentCandle].high;
                const low = data[currentCandle].low;
                const close = data[currentCandle].close;
                
                let shouldExit = false;
                let exitPrice = null;
                let exitReason = null;
                
                // Check for stop loss (intraday movement matters)
                if ((isLong && low <= trade.stopLoss) || (!isLong && high >= trade.stopLoss)) {
                    shouldExit = true;
                    exitPrice = trade.stopLoss;
                    exitReason = "Stop Loss";
                }
                // Check for take profit (intraday movement matters)
                else if ((isLong && high >= trade.takeProfit) || (!isLong && low <= trade.takeProfit)) {
                    shouldExit = true;
                    exitPrice = trade.takeProfit;
                    exitReason = "Take Profit";
                }
                // Check for counter signal
                else {
                    const counterScore = isLong 
                        ? calculateShortTradeScore(data, currentCandle, allData.fibLevels, allData.channels, allData.emas, 0.005)
                        : calculateLongTradeScore(data, currentCandle, allData.fibLevels, allData.channels, allData.emas, 0.005);
                    
                    if (counterScore.valid && counterScore.score >= 90) {
                        shouldExit = true;
                        exitPrice = close;
                        exitReason = "Counter Signal";
                    }
                }
                
                // Time-based exit
                if (!shouldExit && trade.barsInTrade >= maxBarsInTrade) {
                    shouldExit = true;
                    exitPrice = close;
                    exitReason = "Time Exit";
                }
                
                // Process exit if needed
                if (shouldExit) {
                    const signal = trade.signal;
                    
                    // Record completed trade with real-time exit info
                    const exitIndex = currentCandle;
                    const pnlPoints = isLong ? exitPrice - trade.entry : trade.entry - exitPrice;
                    const pnlPercent = (pnlPoints / trade.entry) * 100;
                    const reward = Math.abs(pnlPercent);
                    const risk = stopLossPercent * 100;
                    const riskRewardRatio = reward / risk;
                    
                    trades.push({
                        signalIndex: signal.index,
                        signalDate: signal.date,
                        signalPrice: trade.entry,
                        exitIndex: exitIndex,
                        exitDate: new Date(data[exitIndex].date),
                        exitPrice: exitPrice,
                        exitReason: exitReason,
                        pnlPoints: pnlPoints,
                        pnlPercent: pnlPercent,
                        barsInTrade: trade.barsInTrade,
                        isWin: pnlPercent > 0,
                        type: isLong ? "LONG" : "SHORT", 
                        stopLossLevel: trade.stopLoss,
                        takeProfitLevel: trade.takeProfit,
                        stopLossHit: exitReason === "Stop Loss",
                        risk: risk.toFixed(2) + "%",
                        reward: reward.toFixed(2) + "%",
                        riskRewardRatio: riskRewardRatio.toFixed(2)
                    });
                } else {
                    // Keep trade active
                    remainingTrades.push(trade);
                }
            }
            
            // Update active trades
            activeTrades = remainingTrades;
        }
        
        // Handle any trades still open at end of data
        activeTrades.forEach(trade => {
            const lastCandle = endPoint;
            const signal = trade.signal;
            const exitPrice = data[lastCandle].close;
            const exitReason = "End of Test";
            
            // Calculate final trade metrics
            const pnlPoints = isLong ? exitPrice - trade.entry : trade.entry - exitPrice;
            const pnlPercent = (pnlPoints / trade.entry) * 100;
            
            // Calculate risk (distance to stop loss from entry)
            const risk = stopLossPercent * 100; // Convert to percentage
            
            // Calculate reward (distance from entry to exit)
            const reward = Math.abs(pnlPercent);
            
            // Calculate risk/reward ratio
            const riskRewardRatio = reward / risk;
            
            // Record trade with detailed information
            trades.push({
                signalIndex: signal.index,
                signalDate: signal.date,
                signalPrice: trade.entry,
                exitIndex: lastCandle,
                exitDate: new Date(data[lastCandle].date),
                exitPrice: exitPrice,
                exitReason: exitReason,
                pnlPoints: pnlPoints,
                pnlPercent: pnlPercent,
                barsInTrade: trade.barsInTrade,
                isWin: pnlPercent > 0,
                type: isLong ? "LONG" : "SHORT", 
                stopLossLevel: trade.stopLoss,
                takeProfitLevel: trade.takeProfit,
                stopLossHit: false,
                risk: risk.toFixed(2) + "%",
                reward: reward.toFixed(2) + "%",
                riskRewardRatio: riskRewardRatio.toFixed(2)
            });
        });
        
        return trades;
    };
    
    // Simulate trades for long and short signals
    const longTrades = simulateTrades(longSignals, true);
    const shortTrades = simulateTrades(shortSignals, false);
    
    // Calculate performance metrics
    const allTrades = [...longTrades, ...shortTrades];
    let totalPnl = 0;
    let wins = 0;
    let losses = 0;
    let breakeven = 0;
    let maxDrawdown = 0;
    let runningPnl = 0;
    let peakValue = 0;
    
    allTrades.sort((a, b) => a.signalDate - b.signalDate);
    
    allTrades.forEach(trade => {
        totalPnl += trade.pnlPercent;
        runningPnl += trade.pnlPercent;
        
        // Update peak and drawdown
        if (runningPnl > peakValue) {
            peakValue = runningPnl;
        } else {
            const drawdown = peakValue - runningPnl;
            if (drawdown > maxDrawdown) {
                maxDrawdown = drawdown;
            }
        }
        
        // Count wins/losses
        if (trade.pnlPercent > 0.5) wins++;
        else if (trade.pnlPercent < -0.5) losses++;
        else breakeven++;
    });
    
    // Update performance metrics
    backTestResults.longSignals = longSignals;
    backTestResults.shortSignals = shortSignals;
    backTestResults.longTrades = longTrades;
    backTestResults.shortTrades = shortTrades;
    backTestResults.performance = {
        wins: wins,
        losses: losses,
        breakeven: breakeven,
        totalReturn: totalPnl.toFixed(2) + "%",
        winRate: allTrades.length > 0 ? (wins / allTrades.length * 100).toFixed(2) + "%" : "N/A",
        averageReturn: allTrades.length > 0 ? (totalPnl / allTrades.length).toFixed(2) + "%" : "0%",
        maxDrawdown: maxDrawdown.toFixed(2) + "%",
        totalTrades: allTrades.length
    };
    
    // Log backtest results
    logMessage(`Backtest complete: ${allTrades.length} total trades`);
    logMessage(`Performance: ${wins} wins, ${losses} losses, ${breakeven} breakeven`);
    logMessage(`Total return: ${backTestResults.performance.totalReturn}, Average: ${backTestResults.performance.averageReturn}`);
    logMessage(`Win rate: ${backTestResults.performance.winRate}, Max drawdown: ${backTestResults.performance.maxDrawdown}`);
    
    return backTestResults;
}

// Function to add backtest markers to the chart
function addBacktestMarkersToChart(backTestResults, dates) {
    if (!backTestResults || !stockChart) return;
    
    const longSignalTrace = {
        x: backTestResults.longSignals.map(s => s.date),
        y: backTestResults.longSignals.map(s => s.price),
        mode: 'markers',
        type: 'scatter',
        name: 'Long Signals',
        marker: {
            color: 'green',
            size: backTestResults.longSignals.map(s => Math.min(8 + (s.score - 90) / 2, 14)), // Size increases with score above 90
            symbol: 'triangle-up',
            line: {
                color: 'white',
                width: 1
            }
        },
        hoverinfo: 'text',
        text: backTestResults.longSignals.map(s => 
            `High-Quality Long Signal<br>Date: ${s.date.toLocaleDateString()}<br>Price: ${s.price.toFixed(2)}<br>Score: ${s.score}%<br>Candle Index: ${s.index}`
        ),
        yaxis: 'y'
    };
    
    const shortSignalTrace = {
        x: backTestResults.shortSignals.map(s => s.date),
        y: backTestResults.shortSignals.map(s => s.price),
        mode: 'markers',
        type: 'scatter',
        name: 'Short Signals',
        marker: {
            color: 'red',
            size: backTestResults.shortSignals.map(s => Math.min(8 + (s.score - 90) / 2, 14)), // Size increases with score above 90
            symbol: 'triangle-down',
            line: {
                color: 'white',
                width: 1
            }
        },
        hoverinfo: 'text',
        text: backTestResults.shortSignals.map(s => 
            `High-Quality Short Signal<br>Date: ${s.date.toLocaleDateString()}<br>Price: ${s.price.toFixed(2)}<br>Score: ${s.score}%<br>Candle Index: ${s.index}`
        ),
        yaxis: 'y'
    };
    
    // Add winning trades with line connecting entry and exit
    const longWinTraces = backTestResults.longTrades.filter(t => t.isWin).map(trade => {
        return {
            x: [trade.signalDate, trade.exitDate],
            y: [trade.signalPrice, trade.exitPrice],
            mode: 'lines+markers',
            type: 'scatter',
            line: {
                color: 'rgba(0, 200, 0, 0.7)',
                width: 2
            },
            marker: {
                color: ['green', 'blue'],
                size: [8, 8],
                symbol: ['triangle-up', 'circle']
            },
            hoverinfo: 'text',
            text: [`Entry: ${trade.signalPrice.toFixed(2)}`, 
                   `Exit: ${trade.exitPrice.toFixed(2)}<br>P&L: ${trade.pnlPercent.toFixed(2)}%<br>Reason: ${trade.exitReason}`],
            yaxis: 'y',
            showlegend: false
        };
    });
    
    const shortWinTraces = backTestResults.shortTrades.filter(t => t.isWin).map(trade => {
        return {
            x: [trade.signalDate, trade.exitDate],
            y: [trade.signalPrice, trade.exitPrice],
            mode: 'lines+markers',
            type: 'scatter',
            line: {
                color: 'rgba(200, 0, 0, 0.7)',
                width: 2
            },
            marker: {
                color: ['red', 'blue'],
                size: [8, 8],
                symbol: ['triangle-down', 'circle']
            },
            hoverinfo: 'text',
            text: [`Entry: ${trade.signalPrice.toFixed(2)}`, 
                   `Exit: ${trade.exitPrice.toFixed(2)}<br>P&L: ${trade.pnlPercent.toFixed(2)}%<br>Reason: ${trade.exitReason}`],
            yaxis: 'y',
            showlegend: false
        };
    });
    
    // Add losing trades
    const longLossTraces = backTestResults.longTrades.filter(t => !t.isWin).map(trade => {
        return {
            x: [trade.signalDate, trade.exitDate],
            y: [trade.signalPrice, trade.exitPrice],
            mode: 'lines+markers',
            type: 'scatter',
            line: {
                color: 'rgba(0, 200, 0, 0.3)',
                width: 1,
                dash: 'dot'
            },
            marker: {
                color: ['green', 'red'],
                size: [8, 8],
                symbol: ['triangle-up', 'x']
            },
            hoverinfo: 'text',
            text: [`Entry: ${trade.signalPrice.toFixed(2)}`, 
                   `Exit: ${trade.exitPrice.toFixed(2)}<br>P&L: ${trade.pnlPercent.toFixed(2)}%<br>Reason: ${trade.exitReason}`],
            yaxis: 'y',
            showlegend: false
        };
    });
    
    const shortLossTraces = backTestResults.shortTrades.filter(t => !t.isWin).map(trade => {
        return {
            x: [trade.signalDate, trade.exitDate],
            y: [trade.signalPrice, trade.exitPrice],
            mode: 'lines+markers',
            type: 'scatter',
            line: {
                color: 'rgba(200, 0, 0, 0.3)',
                width: 1,
                dash: 'dot'
            },
            marker: {
                color: ['red', 'green'],
                size: [8, 8],
                symbol: ['triangle-down', 'x']
            },
            hoverinfo: 'text',
            text: [`Entry: ${trade.signalPrice.toFixed(2)}`, 
                   `Exit: ${trade.exitPrice.toFixed(2)}<br>P&L: ${trade.pnlPercent.toFixed(2)}%<br>Reason: ${trade.exitReason}`],
            yaxis: 'y',
            showlegend: false
        };
    });
    
    // Combine all traces
    const allTraces = [
        longSignalTrace,
        shortSignalTrace,
        ...longWinTraces,
        ...shortWinTraces,
        ...longLossTraces,
        ...shortLossTraces
    ];
    
    // Update the chart with the new traces
    Plotly.addTraces('stockChart', allTraces);
    
    // Log that chart visualization is limited to backtest range
    const endPointInput = document.getElementById('backtestEndPoint');
    logMessage(`Chart visualization limited to candles up to index ${endPointInput && endPointInput.value ? endPointInput.value : "end of data"}`);
    
    // Update backtesting results in the UI
    updateBacktestResultsUI(backTestResults);
}

// Function to update the UI with backtest results
function updateBacktestResultsUI(results) {
    // Make sure the backtest results container exists
    const container = document.getElementById('backtestResults');
    if (!container) return;
    
    // Combine all trades and sort by date in descending order (newest first)
    const allTrades = [...results.longTrades, ...results.shortTrades].sort((a, b) => b.signalDate - a.signalDate);
    
    // Detect if we're on mobile
    const isMobile = window.innerWidth < 768;
    
    // Create the detailed trades table rows with mobile optimization
    const tradeRows = allTrades.map(trade => {
        const tradeType = trade.type;
        // Format dates in Month/Day/Year format with time (shortened for mobile)
        const entryDate = isMobile ? formatDateMDY(trade.signalDate).split(' ')[0] : formatDateMDY(trade.signalDate);
        const entryPrice = trade.signalPrice.toFixed(2);
        const exitDate = isMobile ? formatDateMDY(trade.exitDate).split(' ')[0] : formatDateMDY(trade.exitDate);
        const exitPrice = trade.exitPrice.toFixed(2);
        const pnl = trade.pnlPercent.toFixed(2) + '%';
        const stopLossHit = trade.stopLossHit ? 'Yes' : 'No';
        const riskReward = trade.riskRewardRatio;
        const exitReason = isMobile ? 
                          (trade.exitReason.length > 10 ? trade.exitReason.substring(0, 10) + '...' : trade.exitReason) : 
                          trade.exitReason;
        const barsInTrade = trade.barsInTrade;
        
        // Add color based on profit/loss
        const rowClass = trade.isWin ? 'table-success' : 'table-danger';
        
        return `
            <tr class="${rowClass}">
                <td>${tradeType}</td>
                <td>${entryDate}</td>
                <td>$${entryPrice}</td>
                <td>${isMobile ? pnl : exitDate}</td>
                ${isMobile ? '' : `<td>$${exitPrice}</td>`}
                ${isMobile ? '' : `<td>${pnl}</td>`}
                <td>${stopLossHit}</td>
                ${isMobile ? '' : `<td>${riskReward}</td>`}
                <td>${exitReason}</td>
                ${isMobile ? '' : `<td>${barsInTrade}</td>
                <td>${trade.signalIndex !== undefined ? trade.signalIndex : 'N/A'}</td>
                <td>${trade.exitIndex !== undefined ? trade.exitIndex : 'N/A'}</td>`}
            </tr>
        `;
    }).join('');
    
    // Create the main HTML 
    const html = `
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Backtest Results</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Performance</h6>
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Total Trades:</span>
                                <strong>${results.performance.totalTrades}</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Win / Loss / Breakeven:</span>
                                <strong>${results.performance.wins} / ${results.performance.losses} / ${results.performance.breakeven}</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Win Rate:</span>
                                <strong>${results.performance.winRate}</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Total Return:</span>
                                <strong>${results.performance.totalReturn}</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Average Return:</span>
                                <strong>${results.performance.averageReturn}</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Max Drawdown:</span>
                                <strong>${results.performance.maxDrawdown}</strong>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <h6>Signals</h6>
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Long Signals:</span>
                                <strong>${results.longSignals.length}</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Short Signals:</span>
                                <strong>${results.shortSignals.length}</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Long Trades:</span>
                                <strong>${results.longTrades.length}</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Short Trades:</span>
                                <strong>${results.shortTrades.length}</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Long Win Rate:</span>
                                <strong>${results.longTrades.length > 0 ? 
                                    ((results.longTrades.filter(t => t.isWin).length / results.longTrades.length) * 100).toFixed(2) + '%' : 
                                    'N/A'}</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Short Win Rate:</span>
                                <strong>${results.shortTrades.length > 0 ? 
                                    ((results.shortTrades.filter(t => t.isWin).length / results.shortTrades.length) * 100).toFixed(2) + '%' : 
                                    'N/A'}</strong>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Detailed Trades Table -->
        <div class="card">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">Detailed Trade List</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered mb-0">
                        <thead class="thead-dark">
                            <tr>
                                <th>Type</th>
                                <th>Entry Time</th>
                                <th>Entry Price</th>
                                ${isMobile ? '<th>P/L</th>' : '<th>Exit Time</th>'}
                                ${isMobile ? '' : '<th>Exit Price</th>'}
                                ${isMobile ? '' : '<th>P/L</th>'}
                                <th>SL Hit</th>
                                ${isMobile ? '' : '<th>Risk/Reward</th>'}
                                <th>Exit Reason</th>
                                ${isMobile ? '' : `<th>Bars Held</th>
                                <th>Entry Index</th>
                                <th>Exit Index</th>`}
                            </tr>
                        </thead>
                        <tbody>
                            ${tradeRows}
                        </tbody>
                    </table>
                </div>
                ${isMobile && allTrades.length > 0 ? `
                <div class="mt-2 text-center">
                    <small class="text-muted"><i class="fas fa-arrows-alt-h"></i> Swipe horizontally to see more details</small>
                </div>
                ` : ''}
            </div>
        </div>
    `;
    
    // Update the container
    container.innerHTML = html;
    container.classList.remove('d-none');
    
    // Log trade details to console for easier inspection
    console.table(allTrades.map(t => ({
        Type: t.type,
        Entry: formatDateMDY(t.signalDate),
        EntryPrice: t.signalPrice.toFixed(2),
        Exit: formatDateMDY(t.exitDate),
        ExitPrice: t.exitPrice.toFixed(2),
        'P/L': t.pnlPercent.toFixed(2) + '%',
        StopLossHit: t.stopLossHit ? 'Yes' : 'No',
        'Risk/Reward': t.riskRewardRatio,
        ExitReason: t.exitReason,
        EntryIndex: t.signalIndex !== undefined ? t.signalIndex : 'N/A',
        ExitIndex: t.exitIndex !== undefined ? t.exitIndex : 'N/A'
    })));
    
    // Print trade details to log
    logMessage(`------ DETAILED TRADE LIST (${allTrades.length} trades) ------`);
    allTrades.forEach((trade, index) => {
        logMessage(`Trade #${index + 1} (${trade.type}): Entry ${formatDateMDY(trade.signalDate)} at $${trade.signalPrice.toFixed(2)}, Exit ${formatDateMDY(trade.exitDate)} at $${trade.exitPrice.toFixed(2)}`);
        logMessage(`    P/L: ${trade.pnlPercent.toFixed(2)}%, Stop Loss Hit: ${trade.stopLossHit ? 'Yes' : 'No'}, Risk/Reward: ${trade.riskRewardRatio}, Exit: ${trade.exitReason}`);
        logMessage(`    Entry Index: ${trade.signalIndex !== undefined ? trade.signalIndex : 'N/A'}, Exit Index: ${trade.exitIndex !== undefined ? trade.exitIndex : 'N/A'}`);
    });
}

// Helper function to apply theme-dependent styling to an axis object
function applyAxisTheme(axis) {
    if (!axis) return axis;
    
    // Apply theme colors
    axis.linecolor = darkTheme ? '#363636' : '#d0d0d0';
    axis.gridcolor = darkTheme ? 'rgba(60, 60, 60, 0.8)' : 'rgba(220, 220, 220, 0.8)';
    
    // Style fonts
    if (axis.title && axis.title.font) {
        axis.title.font.color = darkTheme ? '#8e8e8e' : '#666666';
    }
    
    if (axis.tickfont) {
        axis.tickfont.color = darkTheme ? '#8e8e8e' : '#666666';
    }
    
    // Style zero line if present
    if (axis.zeroline) {
        axis.zerolinecolor = darkTheme ? '#555' : '#aaa';
    }
    
    return axis;
}

function createStockChart(data, allData, isAutoRefresh = false, forceZoomReset = false) {
    // Performance monitoring
    const startTime = performance.now();
    
    // Store current zoom state if auto-refreshing and not forcing zoom reset
    const savedZoomState = (isAutoRefresh && !forceZoomReset) ? lastZoomState : null;
    
    // Reset zoom state if we're forcing a reset
    if (forceZoomReset) {
        lastZoomState = null;
        logMessage('Forcing zoom reset due to forceZoomReset parameter');
    }
    // Clear any existing chart
    Plotly.purge('stockChart');
    
    // Show loading indicator
    document.getElementById('loading').classList.remove('d-none');
    
    const symbol = allData.symbol;
    
    // Set chart title
    document.getElementById('chartTitle').textContent = `Stock Price Analysis for ${symbol}`;
    
    if (!data || data.length === 0) {
        logMessage(`Error: No data available for ${symbol}`);
        document.getElementById('loading').classList.add('d-none');
        
        // Display error message on the chart area
        Plotly.newPlot('stockChart', [], {
            annotations: [{
                text: `No data available for ${symbol}. Please check the symbol and try again.`,
                xref: 'paper',
                yref: 'paper',
                x: 0.5,
                y: 0.5,
                showarrow: false,
                font: {
                    size: 20
                }
            }]
        });
        return;
    }
    
    // Process data for candlestick chart more efficiently
    const dataLength = data.length;
    const dates = new Array(dataLength);
    const opens = new Array(dataLength);
    const highs = new Array(dataLength);
    const lows = new Array(dataLength);
    const closes = new Array(dataLength);
    const volumes = new Array(dataLength);
    const candleHoverTexts = new Array(dataLength);
    const volumeColors = new Array(dataLength);
    const volumeHoverTexts = new Array(dataLength);
    
    // Calculate values in a single loop for better performance
    let maxPrice = -Infinity;
    let maxVolume = -Infinity;
    let totalVolume = 0;
    let item, date;
    
    // Single loop for data preparation - much more efficient
    for (let i = 0; i < dataLength; i++) {
        item = data[i];
        // Create date objects once
        date = new Date(item.date);
        dates[i] = date;
        
        // Store price data
        opens[i] = item.open;
        highs[i] = item.high;
        lows[i] = item.low;
        closes[i] = item.close;
        volumes[i] = item.volume;
        
        // Find max values inline
        if (highs[i] > maxPrice) maxPrice = highs[i];
        if (volumes[i] > maxVolume) maxVolume = volumes[i];
        
        // Sum volume for average calculation
        totalVolume += volumes[i];
        
        // Prepare hover texts
        candleHoverTexts[i] = `O: ${item.open.toFixed(2)}<br>H: ${item.high.toFixed(2)}<br>L: ${item.low.toFixed(2)}<br>C: ${item.close.toFixed(2)}<br>Candle Index: ${i}`;
        volumeHoverTexts[i] = `Volume: ${item.volume.toLocaleString()}<br>Close: ${item.close.toFixed(2)}`;
        
        // Determine if bullish or bearish
        volumeColors[i] = closes[i] > opens[i] 
            ? 'rgba(32, 208, 194, 0.6)'  // Teal for bullish candles (#20D0C2)
            : 'rgba(220, 0, 0, 0.6)';    // Red for bearish candles
    }
    
    // Calculate average volume and scale factor
    const avgVolume = totalVolume / dataLength;
    const scaleFactor = maxPrice / maxVolume * 0.2;
    
    // Create candlestick trace
    const candlestickTrace = {
        x: dates,
        open: opens,
        high: highs,
        low: lows,
        close: closes,
        type: 'candlestick',
        name: 'Price',
        increasing: {line: {color: '#26a69a'}},
        decreasing: {line: {color: '#ef5350'}},
        hoverinfo: 'text',
        text: candleHoverTexts
    };
    
    // Create volume trace with colored bars
    const volumeTrace = {
        x: dates,
        y: volumes,
        type: 'bar',
        name: 'Volume',
        marker: {
            color: volumeColors,
            line: {
                color: 'rgba(0, 0, 0, 0)',
                width: 0
            }
        },
        hoverinfo: 'text',
        text: volumeHoverTexts,
        yaxis: 'y2',
        showlegend: false
    };
    
    // Create average volume line (pre-allocating the array)
    const avgVolumeValues = new Array(dataLength).fill(avgVolume);
    const avgVolumeTrace = {
        x: dates,
        y: avgVolumeValues,
        type: 'scatter',
        mode: 'lines',
        line: {
            color: 'rgba(184, 80, 66, 0.8)', // Changed to brownish-red (#B85042) to match our theme
            width: 2,
            dash: 'dash'
        },
        name: 'Avg Volume',
        hoverinfo: 'text',
        text: `Avg Volume: ${avgVolume.toLocaleString()}`,
        yaxis: 'y2',
        showlegend: false
    };
    
    // Initialize traces array with the basic traces
    let traces = [candlestickTrace, volumeTrace, avgVolumeTrace];
    
    // Add EMAs to the chart if enabled
    if (showEMAs) {
        const emaTraces = createEMATraces(dates, data);
        traces = traces.concat(emaTraces);
        if (emaTraces.length > 0) {
            logMessage(`Added ${emaTraces.length} EMAs to the chart`);
        }
    }
    
    // Add RSI indicator if available and enabled
    if (showRSI) {
        const rsiTraces = createRSITraces(dates, data);
        traces = traces.concat(rsiTraces);
        if (rsiTraces.length > 0) {
            logMessage('Added RSI indicator to the chart');
        }
    }
    
    // Add MACD indicator if available and enabled
    if (showMACD) {
        const macdTraces = createMACDTraces(dates, data);
        traces = traces.concat(macdTraces);
        if (macdTraces.length > 0) {
            logMessage('Added MACD indicator to the chart');
        }
    }
    
    // Add Bollinger Bands if available and enabled
    if (showBB) {
        const bbTraces = createBollingerBandTraces(dates, data);
        traces = traces.concat(bbTraces);
        if (bbTraces.length > 0) {
            logMessage('Added Bollinger Bands to the chart');
        }
    }
    
    // Add ATR indicator if available and enabled
    if (showATR) {
        const atrTraces = createATRTraces(dates, data);
        traces = traces.concat(atrTraces);
        if (atrTraces.length > 0) {
            logMessage('Added ATR indicator to the chart');
        }
    }
    
    // Add channel lines and transitions if available and enabled
    if (showChannels) {
        // Check if channels data exists
        if (allData.channels && allData.channels.length > 0) {
            const channelTraces = createChannelTraces(dates, allData.channels, data, allData.fibLevels);
            traces = traces.concat(channelTraces);
            logMessage(`Added ${allData.channels.length} price channels to the chart`);
        }
        
        // Check if transition data exists
        if (allData.channelChanges && allData.channelChanges.length > 0) {
            const transitionTraces = createTransitionTraces(dates, allData.channelChanges, data);
            traces = traces.concat(transitionTraces);
            logMessage(`Added ${allData.channelChanges.length} channel transitions to the chart`);
        }
    }
    
    // Add Fibonacci levels if available and enabled
    if (showFibLevels && allData.fibLevels) {
        const fibTraces = createFibonacciTraces(dates, allData.fibLevels);
        traces = traces.concat(fibTraces);
        logMessage(`Added Fibonacci retracement levels to the chart`);
    }
    
    // Add hover points for channel values if channels exist
    if (allData.channels && allData.channels.length > 0) {
        const channelValueTraces = createChannelValueHoverPoints(dates, allData.channels, data);
        traces = traces.concat(channelValueTraces);
        logMessage(`Added channel value hover points to the chart`);
    }
    
    // Check if this is a mobile device based on screen width
    const isMobile = window.innerWidth < 768;
    
    // Chart layout with shared x-axis between price and volume panels
    // Update grid based on which indicators are shown
    const numRows = 2 + // Base rows for price and volume
        (showRSI ? 1 : 0) + 
        (showMACD ? 1 : 0) + 
        (showATR ? 1 : 0);
        
    // Calculate domain heights for each component
    // Adjust heights for mobile vs desktop
    const priceHeight = isMobile ? 0.7 : 0.65; // More space for price chart on mobile
    const volumeHeight = isMobile ? 0.08 : 0.10; // Smaller volume panel on mobile
    const indicatorHeight = (1 - priceHeight - volumeHeight) / (numRows - 2 || 1); // Remaining space divided among indicators
    
    // Calculate domain values for each component
    let domains = [];
    let currentTop = 1;
    
    // Price domain at the top
    const priceDomain = [currentTop - priceHeight, currentTop];
    domains.push(priceDomain);
    currentTop -= priceHeight;
    
    // Indicator domains in the middle (if any)
    const rsiDomain = showRSI ? [currentTop - indicatorHeight, currentTop] : null;
    if (rsiDomain) {
        domains.push(rsiDomain);
        currentTop -= indicatorHeight;
    }
    
    const macdDomain = showMACD ? [currentTop - indicatorHeight, currentTop] : null;
    if (macdDomain) {
        domains.push(macdDomain);
        currentTop -= indicatorHeight;
    }
    
    const atrDomain = showATR ? [currentTop - indicatorHeight, currentTop] : null;
    if (atrDomain) {
        domains.push(atrDomain);
        currentTop -= indicatorHeight;
    }
    
    // Volume domain at the bottom
    const volumeDomain = [0, volumeHeight];
    domains.push(volumeDomain);
    
    // Configure layout with calculated domains
    const layout = {
        // Removed duplicate title as we already have HTML title element
        dragmode: 'zoom',
        showlegend: false, // Disable legend for cleaner UI
        
        // Apply custom theme styling based on selected theme
        paper_bgcolor: darkTheme ? 'rgba(30, 30, 35, 0.98)' : 'rgba(255, 255, 255, 0.98)', // Dark/light background for the paper
        plot_bgcolor: darkTheme ? 'rgba(30, 30, 35, 0.95)' : 'rgba(248, 249, 250, 0.95)', // Slightly darker/lighter for the plot area
        
        // Improved font styling - color changes based on theme
        font: {
            family: 'Tahoma, Arial, sans-serif',
            size: isMobile ? 10 : 12,
            color: darkTheme ? '#CCCCCC' : '#333333'  // Light text for dark theme, dark text for light theme
        },
        
        grid: {
            rows: numRows,
            columns: 1,
            pattern: 'coupled',  // Share x-axis
            roworder: 'top to bottom',
            rowgap: 0.03 // Small gap between plots
        },
        
        xaxis: {
            rangeslider: {
                visible: false
            },
            title: {
                text: 'Date',
                font: {
                    family: 'Tahoma, Arial, sans-serif',
                    size: isMobile ? 10 : 12,
                    color: '#8e8e8e'
                }
            },
            type: 'date',
            domain: [0, 1],
            anchor: 'y',
            linecolor: darkTheme ? '#363636' : '#d0d0d0',
            gridcolor: darkTheme ? 'rgba(60, 60, 60, 0.8)' : 'rgba(220, 220, 220, 0.8)',
            gridwidth: 1,
            showgrid: true,
            tickfont: {
                family: 'Tahoma, Arial, sans-serif',
                size: 10,
                color: darkTheme ? '#8e8e8e' : '#666666'
            },
            zeroline: false,
            showline: true
        },
        
        yaxis: {
            title: {
                text: 'Price ($)',
                font: {
                    family: 'Tahoma, Arial, sans-serif',
                    size: isMobile ? 10 : 12,
                    color: '#8e8e8e'
                }
            },
            autorange: true,
            domain: priceDomain,
            constrain: 'domain', // Maintain aspect ratio when zooming
            linecolor: darkTheme ? '#363636' : '#d0d0d0',
            gridcolor: darkTheme ? 'rgba(60, 60, 60, 0.8)' : 'rgba(220, 220, 220, 0.8)',
            gridwidth: 1,
            showgrid: true,
            tickfont: {
                family: 'Tahoma, Arial, sans-serif',
                size: 10,
                color: darkTheme ? '#8e8e8e' : '#666666'
            },
            zeroline: true,
            zerolinecolor: '#555',
            zerolinewidth: 1,
            showline: true
        },
        
        yaxis2: {
            title: {
                text: 'Volume',
                font: {
                    family: 'Tahoma, Arial, sans-serif',
                    size: isMobile ? 10 : 12,
                    color: '#8e8e8e'
                }
            },
            domain: volumeDomain,
            autorange: true,
            anchor: 'x',  // Share the same x-axis
            linecolor: darkTheme ? '#363636' : '#d0d0d0',
            gridcolor: darkTheme ? 'rgba(60, 60, 60, 0.8)' : 'rgba(220, 220, 220, 0.8)',
            gridwidth: 1,
            showgrid: true,
            tickfont: {
                family: 'Tahoma, Arial, sans-serif',
                size: 10,
                color: darkTheme ? '#8e8e8e' : '#666666'
            },
            showline: true
        },
        
        margin: {
            l: isMobile ? 40 : 60, 
            r: isMobile ? 25 : 40,
            b: isMobile ? 25 : 30,
            t: isMobile ? 30 : 40,
            pad: isMobile ? 2 : 4
        },
        
        hovermode: 'closest',
        
        // Add subtle border shadow to enhance visual appearance
        shapes: [{
            type: 'rect',
            xref: 'paper',
            yref: 'paper',
            x0: 0,
            y0: 0,
            x1: 1,
            y1: 1,
            line: {
                width: 1,
                color: 'rgba(0,0,0,0.1)'
            }
        }]
    };
    
    // Add RSI y-axis if enabled
    if (showRSI) {
        layout.yaxis3 = {
            title: {
                text: 'RSI',
                font: {
                    family: 'Tahoma, Arial, sans-serif',
                    size: isMobile ? 10 : 12,
                    color: '#8e8e8e'
                }
            },
            domain: rsiDomain,
            range: [0, 100], // RSI always between 0-100
            anchor: 'x',
            overlaying: false,
            rangemode: 'tozero',
            linecolor: '#363636',
            gridcolor: 'rgba(60, 60, 60, 0.8)',
            gridwidth: 1,
            tickfont: {
                family: 'Tahoma, Arial, sans-serif',
                size: 10,
                color: '#8e8e8e'
            },
            showgrid: true,
            showline: true
        };
        
        // Apply theme styling to RSI axis
        layout.yaxis3 = applyAxisTheme(layout.yaxis3);
    }
    
    // Add MACD y-axis if enabled
    if (showMACD) {
        layout.yaxis4 = {
            title: {
                text: 'MACD',
                font: {
                    family: 'Tahoma, Arial, sans-serif',
                    size: isMobile ? 10 : 12,
                    color: '#8e8e8e'
                }
            },
            domain: macdDomain,
            anchor: 'x',
            overlaying: false,
            rangemode: 'normal',
            linecolor: '#363636',
            gridcolor: 'rgba(60, 60, 60, 0.8)',
            gridwidth: 1,
            tickfont: {
                family: 'Tahoma, Arial, sans-serif',
                size: 10,
                color: '#8e8e8e'
            },
            showgrid: true,
            showline: true
        };
        
        // Apply theme styling to MACD axis
        layout.yaxis4 = applyAxisTheme(layout.yaxis4);
    }
    
    // Add ATR y-axis if enabled
    if (showATR) {
        layout.yaxis5 = {
            title: {
                text: 'ATR',
                font: {
                    family: 'Tahoma, Arial, sans-serif',
                    size: isMobile ? 10 : 12,
                    color: '#8e8e8e'
                }
            },
            domain: atrDomain,
            anchor: 'x',
            overlaying: false,
            rangemode: 'tozero',
            linecolor: '#363636',
            gridcolor: 'rgba(60, 60, 60, 0.8)',
            gridwidth: 1,
            tickfont: {
                family: 'Tahoma, Arial, sans-serif',
                size: 10,
                color: '#8e8e8e'
            },
            showgrid: true,
            showline: true
        };
        
        // Apply theme styling to ATR axis
        layout.yaxis5 = applyAxisTheme(layout.yaxis5);
    }
    
    // Update traces to use the correct subplots
    candlestickTrace.xaxis = 'x';
    candlestickTrace.yaxis = 'y';
    
    // Volume traces go on the second subplot with shared x-axis
    volumeTrace.xaxis = 'x';
    volumeTrace.yaxis = 'y2';
    avgVolumeTrace.xaxis = 'x';
    avgVolumeTrace.yaxis = 'y2';
    
    // Create the chart with mobile-friendly config
    const config = {
        responsive: true,
        displayModeBar: true,
        displaylogo: false,
        modeBarButtonsToRemove: [
            'sendDataToCloud',
            'autoScale2d',
            'resetScale2d',
            'hoverClosestCartesian',
            'hoverCompareCartesian',
            'toggleSpikelines'
        ],
        // Make buttons larger on mobile for better touch targets
        modeBarButtonsToAdd: isMobile ? [{
            name: 'Reset Zoom',
            icon: Plotly.Icons.home,
            click: function(gd) {
                Plotly.relayout(gd, 'xaxis.autorange', true);
                Plotly.relayout(gd, 'yaxis.autorange', true);
            }
        }] : []
    };
    
    // Render the chart
    Plotly.newPlot('stockChart', traces, layout, config);
    
    // Calculate and log performance metrics
    const endTime = performance.now();
    const renderTime = (endTime - startTime).toFixed(2);
    console.log(`Chart rendering completed in ${renderTime}ms. Displaying ${traces.length} traces with ${dataLength} candles.`);
    
    // Add to performance history for tracking
    if (!window.chartPerformance) window.chartPerformance = [];
    window.chartPerformance.push({
        timestamp: new Date(),
        renderTime: parseFloat(renderTime),
        traceCount: traces.length,
        dataPoints: dataLength
    });
    
    // Only keep the last 10 performance records
    if (window.chartPerformance.length > 10) {
        window.chartPerformance.shift();
    }
    
    // Calculate average rendering time from history
    const avgRenderTime = window.chartPerformance.reduce((sum, record) => sum + record.renderTime, 0) / 
                         window.chartPerformance.length;
    
    // Show performance in console for monitoring
    console.log(`Average chart render time: ${avgRenderTime.toFixed(2)}ms (last 10 renders)`);
    
    // Store chart reference
    stockChart = document.getElementById('stockChart');
    
    // Apply zoom settings based on parameters
    if (forceZoomReset) {
        // If forcing zoom reset, use default optimal view
        logMessage('Forced zoom reset: Using optimal default view');
        // We'll continue to the default zoom code below
    } else if (savedZoomState) {
        // If auto-refreshing and not forcing reset, use the saved zoom state
        Plotly.relayout('stockChart', savedZoomState);
        logMessage('Auto-refresh: Preserved previous zoom state');
        return; // Exit early, zoom is set
    } else if (lastZoomState && !forceZoomReset) {
        // If we have a stored zoom state and not forcing reset, use it
        Plotly.relayout('stockChart', lastZoomState);
        logMessage('Using previous zoom state');
        return; // Exit early, zoom is set
    } else {
        logMessage('Setting optimal default zoom view');
        // Calculate optimal view range focusing on most recent data
        try {
            const totalCandles = dates.length;
            if (totalCandles > 0) {
                // Default to showing the most recent data (last 20 candles or less)
                const candles = Math.min(20, totalCandles);
                const startIdx = Math.max(0, totalCandles - candles);
                
                // Calculate price range to display
                let minPrice = Infinity;
                let maxPrice = -Infinity;
                
                // Find min and max prices for these candles
                for (let i = startIdx; i < totalCandles; i++) {
                    const candle = data[i];
                    if (candle) {
                        // Guard against missing or invalid data
                        if (typeof candle.low === 'number' && !isNaN(candle.low)) {
                            minPrice = Math.min(minPrice, candle.low);
                        }
                        if (typeof candle.high === 'number' && !isNaN(candle.high)) {
                            maxPrice = Math.max(maxPrice, candle.high);
                        }
                    }
                }
                
                // Ensure we have valid price range
                if (minPrice !== Infinity && maxPrice !== -Infinity) {
                    // Add padding to price range (5% for better visibility)
                    const priceRange = maxPrice - minPrice;
                    const yPadding = priceRange * 0.05;
                    const yMin = minPrice - yPadding;
                    const yMax = maxPrice + yPadding;
                    
                    // Get date range
                    const startDate = new Date(dates[startIdx]);
                    const endDate = new Date(dates[totalCandles - 1]);
                    
                    // Add date padding for better visibility
                    const timeSpan = endDate.getTime() - startDate.getTime();
                    const paddedStart = new Date(startDate.getTime() - (timeSpan * 0.02));
                    const paddedEnd = new Date(endDate.getTime() + (timeSpan * 0.05));
                    
                    // Apply the zoom
                    const zoomLayout = {
                        'xaxis.range': [paddedStart.toISOString(), paddedEnd.toISOString()],
                        'yaxis.range': [yMin, yMax]
                    };
                    
                    Plotly.relayout('stockChart', zoomLayout);
                    logMessage(`Zoomed to most recent data (${candles} candles)`);
                } else {
                    // Fallback to autorange if we couldn't determine price range
                    Plotly.relayout('stockChart', {
                        'xaxis.autorange': true,
                        'yaxis.autorange': true
                    });
                    logMessage('Using auto-range as default view');
                }
            }
        } catch (error) {
            // Safely handle any errors in the zooming logic
            console.error('Error setting initial zoom:', error);
            logMessage('Error setting initial zoom, using auto-range');
            
            // Fallback to auto-range
            Plotly.relayout('stockChart', {
                'xaxis.autorange': true,
                'yaxis.autorange': true
            });
        }
    }
    
    // Listen for zoom events
    stockChart.on('plotly_relayout', function(eventData) {
        // Store zoom state if it includes x-axis range
        if (eventData['xaxis.range[0]'] || eventData['xaxis.range']) {
            lastZoomState = eventData;
            logMessage('Zoom state updated');
        }
    });
    
    // Hide loading indicator
    document.getElementById('loading').classList.add('d-none');
    
    logMessage(`Chart created successfully for ${symbol} with ${data.length} data points`);
}

// Function to handle auto-refresh
function startAutoRefresh() {
    if (refreshTimer) {
        clearInterval(refreshTimer);
    }
    
    // Enable auto-refresh and update UI
    autoRefreshEnabled = true;
    document.getElementById('toggleAutoRefreshBtn').classList.add('active');
    document.getElementById('toggleAutoRefreshBtn').classList.add('btn-danger');
    document.getElementById('toggleAutoRefreshBtn').classList.remove('btn-outline-secondary');
    document.getElementById('toggleAutoRefreshBtn').innerHTML = '<i class="fas fa-sync-alt"></i> AUTO REFRESH: ON';
    document.getElementById('refreshStatus').classList.remove('d-none');
    
    // Schedule next refresh
    nextRefreshTime = new Date(Date.now() + refreshInterval);
    updateRefreshTimer();
    
    // Start interval to update timer and trigger refresh
    refreshTimer = setInterval(() => {
        // Check if it's time to refresh
        const now = new Date();
        if (now >= nextRefreshTime) {
            // Save current zoom state
            logMessage('Auto-refresh triggered, preserving zoom state');
            fetchStockData(true); // Pass true to indicate auto-refresh
            
            // Schedule next refresh
            nextRefreshTime = new Date(Date.now() + refreshInterval);
        }
        
        // Update countdown timer
        updateRefreshTimer();
    }, 1000); // Update every second
    
    logMessage('Auto-refresh enabled - chart will update every 60 seconds');
}

// Function to stop auto-refresh
function stopAutoRefresh() {
    // Disable auto-refresh and update UI
    autoRefreshEnabled = false;
    if (refreshTimer) {
        clearInterval(refreshTimer);
        refreshTimer = null;
    }
    
    document.getElementById('toggleAutoRefreshBtn').classList.remove('active');
    document.getElementById('toggleAutoRefreshBtn').classList.remove('btn-danger');
    document.getElementById('toggleAutoRefreshBtn').classList.add('btn-outline-secondary');
    document.getElementById('toggleAutoRefreshBtn').innerHTML = '<i class="fas fa-sync-alt"></i> AUTO REFRESH: OFF';
    document.getElementById('refreshStatus').classList.add('d-none');
    
    logMessage('Auto-refresh disabled');
}

// Update the refresh countdown timer
function updateRefreshTimer() {
    if (!nextRefreshTime) return;
    
    const now = new Date();
    const timeDiff = nextRefreshTime - now;
    
    if (timeDiff <= 0) {
        document.getElementById('nextRefreshTime').textContent = 'Refreshing now...';
        return;
    }
    
    // Calculate minutes and seconds
    const seconds = Math.floor((timeDiff / 1000) % 60);
    const minutes = Math.floor((timeDiff / (1000 * 60)) % 60);
    
    // Format as MM:SS
    const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    document.getElementById('nextRefreshTime').textContent = `Next refresh in ${formattedTime}`;
}

// Function to fetch stock data and update the chart
function fetchStockData(isAutoRefresh = false, skipTradeScoreCalc = false) {
    // Get user inputs
    const symbol = document.getElementById('symbolInput').value.toUpperCase();
    const frequency = document.getElementById('frequencySelect').value;
    let days = parseInt(document.getElementById('daysInput').value);
    
    // Store the previous symbol for comparison
    const previousSymbol = window.currentStockSymbol || '';
    
    // Check if symbol has changed
    const symbolChanged = symbol !== previousSymbol;
    
    // ALWAYS reset zoom state when symbol changes, regardless of auto-refresh setting
    if (symbolChanged) {
        lastZoomState = null;
        logMessage(`Symbol changed from ${previousSymbol || 'none'} to ${symbol}, resetting zoom`);
    }
    
    // Update current symbol
    window.currentStockSymbol = symbol;
    
    // Clear any existing backtest results (only if not auto-refreshing)
    if (!isAutoRefresh) {
        clearBacktestResults();
    }
    
    // Validate inputs
    if (!symbol) {
        logMessage('Error: Please enter a valid stock symbol');
        return;
    }
    
    // Set days based on frequency if not manually changed
    if (frequency === '30min' && days === 30) days = 25; // Increased from 15 to 25 days
    if (frequency === '60min' && (days === 15 || days === 90)) days = 45; // Default to 45 days for 60min
    if (frequency === '240min' && days === 30) days = 120; // Increased from 90 to 120 days
    
    // Show loading indicator
    document.getElementById('loading').classList.remove('d-none');
    
    // Log request information
    if (isAutoRefresh) {
        logMessage(`Auto-refreshing data for ${symbol} with ${frequency} data...`);
    } else {
        logMessage(`Analyzing ${symbol} with ${frequency} data for past ${days} days...`);
    }

    // Make API request to our backend
    fetch(`/api/stock-data?symbol=${symbol}&frequency=${frequency}&days=${days}&detectChannels=true`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                throw new Error(data.message || 'Failed to fetch stock data');
            }
            
            // Log success
            logMessage(`Successfully received data for ${symbol}`);
            
            // Check for channel detection results
            if (data.channels) {
                logMessage(`Detected ${data.channels.length} price channels and ${data.channelChanges ? data.channelChanges.length : 0} transitions`);
            }
            
            // Store the data globally for use in backtesting
            window.currentStockData = data;
            
            // Create chart with the data
            // NEVER preserve zoom unless it's an auto-refresh of the same symbol
            const preserveZoom = isAutoRefresh && symbol === previousSymbol;
            
            // Force zoom reset if this was triggered by Analyze Stock button
            const forceZoomReset = !isAutoRefresh;
            createStockChart(data.data, data, preserveZoom, forceZoomReset);
            
            // Calculate and display trade scores (unless explicitly skipped)
            if (!skipTradeScoreCalc) {
                calculateTradeScores(data.data, data);
            } else {
                logMessage("Skipping trade score calculation as requested");
                document.getElementById('status').textContent = 'Chart updated (trade scores unchanged)';
            }
        })
        .catch(error => {
            // Handle errors
            logMessage(`Error: ${error.message}`);
            document.getElementById('loading').classList.add('d-none');
            
            // Display error message on chart
            Plotly.newPlot('stockChart', [], {
                annotations: [{
                    text: `Error: ${error.message}`,
                    xref: 'paper',
                    yref: 'paper',
                    x: 0.5,
                    y: 0.5,
                    showarrow: false,
                    font: {
                        size: 20,
                        color: '#e53935'
                    }
                }]
            });
        });
}

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Log initial message
    logMessage('Stock Analysis App initialized');
    
    // Check if this is a mobile device
    const isMobile = window.innerWidth < 768;
    
    // Apply mobile-specific enhancements if needed
    if (isMobile) {
        // Add tap delay for better touch response
        const buttons = document.querySelectorAll('.btn');
        buttons.forEach(button => {
            button.addEventListener('touchstart', function() {
                this.classList.add('active-touch');
            });
            button.addEventListener('touchend', function() {
                setTimeout(() => {
                    this.classList.remove('active-touch');
                }, 150);
            });
        });
        
        // Make backtest table scrollable on mobile
        document.addEventListener('backtestCreated', function() {
            const tables = document.querySelectorAll('#backtestResults .table');
            tables.forEach(table => {
                const wrapper = document.createElement('div');
                wrapper.className = 'table-responsive';
                table.parentNode.insertBefore(wrapper, table);
                wrapper.appendChild(table);
            });
        });
    }
    
    // Set up event handlers
    document.getElementById('analyzeBtn').addEventListener('click', function() {
        // Always reset zoom state when analyzing a stock
        lastZoomState = null;
        logMessage('Analyze button clicked, resetting zoom state');
        
        // Clear backtest inputs when analyzing a new stock
        clearBacktestResults();
        fetchStockData();
    });
    
    // Auto-refresh toggle button handler
    document.getElementById('toggleAutoRefreshBtn').addEventListener('click', function() {
        if (autoRefreshEnabled) {
            stopAutoRefresh();
        } else {
            // Only enable auto-refresh if we have a chart
            if (!window.currentStockData) {
                logMessage('Please analyze a stock first before enabling auto-refresh');
                return;
            }
            startAutoRefresh();
        }
    });
    
    // Backtest button handler
    document.getElementById('backtestBtn').addEventListener('click', function() {
        // Only run if we have data already loaded
        if (!stockChart || !window.currentStockData) {
            logMessage('Please analyze a stock first before running backtest');
            return;
        }
        
        logMessage('Starting backtest analysis...');
        document.getElementById('loading').classList.remove('d-none');
        
        // Use setTimeout to allow the UI to update before running the CPU-intensive backtesting
        setTimeout(function() {
            // Run backtest with current data
            const backTestResults = runBacktest(
                window.currentStockData.data, 
                window.currentStockData
            );
            
            if (backTestResults) {
                // Add backtest markers to chart
                addBacktestMarkersToChart(backTestResults, window.currentStockData.dates);
                logMessage('Backtest completed and results displayed');
            } else {
                logMessage('Backtest failed - insufficient data for analysis');
            }
            
            document.getElementById('loading').classList.add('d-none');
        }, 100);
    });
    
    // Reset zoom button
    document.getElementById('resetZoomBtn').addEventListener('click', function() {
        if (stockChart) {
            // Reset zoom state first
            lastZoomState = null;
            
            if (window.currentStockData) {
                // Apply our optimized view instead of basic autorange
                const data = window.currentStockData.data;
                const dates = window.currentStockData.dates;
                
                try {
                    const totalCandles = dates.length;
                    if (totalCandles > 0) {
                        // Default to showing the most recent data (last 20 candles or less)
                        const candles = Math.min(20, totalCandles);
                        const startIdx = Math.max(0, totalCandles - candles);
                        
                        // Calculate price range to display
                        let minPrice = Infinity;
                        let maxPrice = -Infinity;
                        
                        // Find min and max prices for these candles
                        for (let i = startIdx; i < totalCandles; i++) {
                            const candle = data[i];
                            if (candle) {
                                if (typeof candle.low === 'number' && !isNaN(candle.low)) {
                                    minPrice = Math.min(minPrice, candle.low);
                                }
                                if (typeof candle.high === 'number' && !isNaN(candle.high)) {
                                    maxPrice = Math.max(maxPrice, candle.high);
                                }
                            }
                        }
                        
                        // Ensure we have valid price range
                        if (minPrice !== Infinity && maxPrice !== -Infinity) {
                            // Add padding to price range (5% for better visibility)
                            const priceRange = maxPrice - minPrice;
                            const yPadding = priceRange * 0.05;
                            const yMin = minPrice - yPadding;
                            const yMax = maxPrice + yPadding;
                            
                            // Get date range
                            const startDate = new Date(dates[startIdx]);
                            const endDate = new Date(dates[totalCandles - 1]);
                            
                            // Add date padding for better visibility
                            const timeSpan = endDate.getTime() - startDate.getTime();
                            const paddedStart = new Date(startDate.getTime() - (timeSpan * 0.02));
                            const paddedEnd = new Date(endDate.getTime() + (timeSpan * 0.05));
                            
                            // Apply the zoom
                            Plotly.relayout('stockChart', {
                                'xaxis.range': [paddedStart.toISOString(), paddedEnd.toISOString()],
                                'yaxis.range': [yMin, yMax]
                            });
                            
                            logMessage('Zoom reset to optimal view');
                            return;
                        }
                    }
                } catch (error) {
                    console.error('Error resetting zoom:', error);
                }
            }
            
            // Fallback to basic autorange if the above fails
            Plotly.relayout('stockChart', {
                'xaxis.autorange': true,
                'yaxis.autorange': true
            });
            logMessage('Zoom reset to auto-range');
        }
    });
    
    // Toggle channels button - performance-optimized version
    document.getElementById('toggleChannelsBtn').addEventListener('click', function() {
        // Get chart element
        const chartElement = document.getElementById('stockChart');
        if (!chartElement) return;
        
        // Toggle visibility
        showChannels = !showChannels;
        this.classList.toggle('active');
        
        // Update UI
        logMessage(`${showChannels ? 'Showing' : 'Hiding'} price channels and transitions`);
        
        if (window.currentStockData && window.currentStockData.channels) {
            const startTime = performance.now();
            
            if (showChannels) {
                // Create channel traces directly
                const channelTraces = createChannelTraces(
                    window.currentStockData.dates,
                    window.currentStockData.channels,
                    window.currentStockData.data
                );
                
                // Create transition traces directly
                const transitionTraces = createTransitionTraces(
                    window.currentStockData.dates,
                    window.currentStockData.channelChanges,
                    window.currentStockData.data
                );
                
                // Create hover traces for channel values if available
                const hoverTraces = createChannelValueHoverPoints(
                    window.currentStockData.dates, 
                    window.currentStockData.channels,
                    window.currentStockData.data
                );
                
                // Add all channel and transition traces to the chart
                const allTraces = [...channelTraces, ...transitionTraces, ...hoverTraces];
                Plotly.addTraces(chartElement, allTraces);
                
                logMessage(`Added ${channelTraces.length} channel traces and ${transitionTraces.length} transition traces in ${(performance.now() - startTime).toFixed(2)}ms`);
                
                // Update status without recalculating trade opportunities
                document.getElementById('status').textContent = 'Price channels and transitions added to chart';
            } else {
                // Hide all channel and transition traces
                const data = chartElement.data;
                if (!data) return;
                
                // Find indices of channel traces to remove (they have custom properties)
                const traceIndicesToRemove = [];
                for (let i = 0; i < data.length; i++) {
                    if (
                        (data[i].name && data[i].name.includes('Channel')) ||
                        (data[i].name && data[i].name.includes('Transition')) ||
                        (data[i].name && data[i].name.includes('Support')) ||
                        (data[i].name && data[i].name.includes('Resistance')) ||
                        (data[i].name && data[i].name.includes('Freeze'))
                    ) {
                        traceIndicesToRemove.push(i);
                    }
                }
                
                // Remove the traces if any were found
                if (traceIndicesToRemove.length > 0) {
                    Plotly.deleteTraces(chartElement, traceIndicesToRemove);
                    logMessage(`Removed ${traceIndicesToRemove.length} price channel and transition traces in ${(performance.now() - startTime).toFixed(2)}ms`);
                    
                    // Update status without recalculating trade opportunities
                    document.getElementById('status').textContent = 'Price channels and transitions removed from chart';
                }
            }
        }
    });
    
    // Toggle Fibonacci levels button - performance-optimized version
    document.getElementById('toggleFibBtn').addEventListener('click', function() {
        // Get chart element
        const chartElement = document.getElementById('stockChart');
        if (!chartElement) return;
        
        // Toggle visibility
        showFibLevels = !showFibLevels;
        this.classList.toggle('active');
        
        // Update UI
        logMessage(`${showFibLevels ? 'Showing' : 'Hiding'} Fibonacci retracement levels`);
        
        if (window.currentStockData && window.currentStockData.fibLevels) {
            const startTime = performance.now();
            
            if (showFibLevels) {
                // Create Fibonacci traces directly
                const fibTraces = createFibonacciTraces(
                    window.currentStockData.dates,
                    window.currentStockData.fibLevels
                );
                
                // Add the Fibonacci traces to the chart
                Plotly.addTraces(chartElement, fibTraces);
                
                logMessage(`Added ${fibTraces.length} Fibonacci level traces in ${(performance.now() - startTime).toFixed(2)}ms`);
                
                // Update status without recalculating trade opportunities
                document.getElementById('status').textContent = 'Fibonacci retracement levels added to chart';
            } else {
                // Hide all Fibonacci traces
                const data = chartElement.data;
                if (!data) return;
                
                // Find indices of Fibonacci traces to remove (they have names containing "Fib")
                const traceIndicesToRemove = [];
                for (let i = 0; i < data.length; i++) {
                    if (data[i].name && data[i].name.includes('Fib')) {
                        traceIndicesToRemove.push(i);
                    }
                }
                
                // Remove the traces if any were found
                if (traceIndicesToRemove.length > 0) {
                    Plotly.deleteTraces(chartElement, traceIndicesToRemove);
                    logMessage(`Removed ${traceIndicesToRemove.length} Fibonacci level traces in ${(performance.now() - startTime).toFixed(2)}ms`);
                    
                    // Update status without recalculating trade opportunities
                    document.getElementById('status').textContent = 'Fibonacci retracement levels removed from chart';
                }
            }
        }
    });
    
    // Store generated traces for each indicator type to avoid recalculations
    let cachedTraces = {
        rsi: [],
        macd: [],
        bb: [],
        atr: [],
        ema: []
    };
    
    // Performance-optimized toggle RSI button
    document.getElementById('toggleRSIBtn').addEventListener('click', function() {
        // Get chart element
        const chartElement = document.getElementById('stockChart');
        if (!chartElement) return;
        
        // Toggle visibility
        showRSI = !showRSI;
        this.classList.toggle('active');
        
        // Update UI
        logMessage(`${showRSI ? 'Showing' : 'Hiding'} RSI indicator`);
        
        if (window.currentStockData) {
            const startTime = performance.now();
            
            if (showRSI) {
                // Show RSI - either use cached traces or create new ones
                if (cachedTraces.rsi.length === 0) {
                    cachedTraces.rsi = createRSITraces(window.currentStockData.dates, window.currentStockData.data);
                }
                
                // Update layout to include RSI subplot if it doesn't exist yet
                const hasRSIPanel = chartElement.layout && chartElement.layout.yaxis3;
                if (!hasRSIPanel) {
                    Plotly.relayout(chartElement, {
                        'yaxis3': {
                            title: 'RSI (14)',
                            domain: [0.05, 0.15],
                            fixedrange: true,
                            range: [0, 100],
                            gridcolor: darkTheme ? 'rgba(80, 80, 80, 0.2)' : 'rgba(200, 200, 200, 0.2)',
                            zerolinecolor: darkTheme ? 'rgba(80, 80, 80, 0.5)' : 'rgba(200, 200, 200, 0.5)',
                            tickfont: {
                                color: darkTheme ? '#AAAAAA' : '#666666'
                            }
                        }
                    });
                }
                
                // Add the RSI traces
                Plotly.addTraces(chartElement, cachedTraces.rsi);
                logMessage(`Added RSI indicator to chart in ${(performance.now() - startTime).toFixed(2)}ms`);
                
                // Update status without recalculating trade opportunities
                document.getElementById('status').textContent = 'RSI indicator added to chart';
            } else {
                // Hide RSI - use more efficient trace filtering
                const data = chartElement.data;
                if (!data) return;
                
                // Find indices of RSI traces to remove (they use yaxis3)
                const traceIndicesToRemove = [];
                for (let i = 0; i < data.length; i++) {
                    if (data[i].yaxis === 'y3') {
                        traceIndicesToRemove.push(i);
                    }
                }
                
                // Remove the traces if any were found
                if (traceIndicesToRemove.length > 0) {
                    Plotly.deleteTraces(chartElement, traceIndicesToRemove);
                    logMessage(`Removed RSI indicator from chart in ${(performance.now() - startTime).toFixed(2)}ms`);
                    
                    // Update status without recalculating trade opportunities
                    document.getElementById('status').textContent = 'RSI indicator removed from chart';
                }
            }
        }
    });
    
    // Performance-optimized toggle MACD button
    document.getElementById('toggleMACDBtn').addEventListener('click', function() {
        // Get chart element
        const chartElement = document.getElementById('stockChart');
        if (!chartElement) return;
        
        // Toggle visibility
        showMACD = !showMACD;
        this.classList.toggle('active');
        
        // Update UI
        logMessage(`${showMACD ? 'Showing' : 'Hiding'} MACD indicator`);
        
        if (window.currentStockData) {
            const startTime = performance.now();
            
            if (showMACD) {
                // Show MACD - either use cached traces or create new ones
                if (cachedTraces.macd.length === 0) {
                    cachedTraces.macd = createMACDTraces(window.currentStockData.dates, window.currentStockData.data);
                }
                
                // Update layout to include MACD subplot if it doesn't exist yet
                const hasMACDPanel = chartElement.layout && chartElement.layout.yaxis4;
                if (!hasMACDPanel) {
                    Plotly.relayout(chartElement, {
                        'yaxis4': {
                            title: 'MACD',
                            domain: [0.16, 0.26],
                            fixedrange: true,
                            gridcolor: darkTheme ? 'rgba(80, 80, 80, 0.2)' : 'rgba(200, 200, 200, 0.2)',
                            zerolinecolor: darkTheme ? 'rgba(80, 80, 80, 0.5)' : 'rgba(200, 200, 200, 0.5)',
                            tickfont: {
                                color: darkTheme ? '#AAAAAA' : '#666666'
                            }
                        }
                    });
                }
                
                // Add the MACD traces
                Plotly.addTraces(chartElement, cachedTraces.macd);
                logMessage(`Added MACD indicator to chart in ${(performance.now() - startTime).toFixed(2)}ms`);
                
                // Update status without recalculating trade opportunities
                document.getElementById('status').textContent = 'MACD indicator added to chart';
            } else {
                // Hide MACD - use more efficient trace filtering
                const data = chartElement.data;
                if (!data) return;
                
                // Find indices of MACD traces to remove (they use yaxis4)
                const traceIndicesToRemove = [];
                for (let i = 0; i < data.length; i++) {
                    if (data[i].yaxis === 'y4') {
                        traceIndicesToRemove.push(i);
                    }
                }
                
                // Remove the traces if any were found
                if (traceIndicesToRemove.length > 0) {
                    Plotly.deleteTraces(chartElement, traceIndicesToRemove);
                    logMessage(`Removed MACD indicator from chart in ${(performance.now() - startTime).toFixed(2)}ms`);
                    
                    // Update status without recalculating trade opportunities
                    document.getElementById('status').textContent = 'MACD indicator removed from chart';
                }
            }
        }
    });
    
    // Performance-optimized toggle Bollinger Bands button
    document.getElementById('toggleBollingerBtn').addEventListener('click', function() {
        // Get chart element
        const chartElement = document.getElementById('stockChart');
        if (!chartElement) return;
        
        // Toggle visibility
        showBB = !showBB;
        this.classList.toggle('active');
        
        // Update UI
        logMessage(`${showBB ? 'Showing' : 'Hiding'} Bollinger Bands`);
        
        if (window.currentStockData) {
            const startTime = performance.now();
            
            if (showBB) {
                // Show Bollinger Bands - either use cached traces or create new ones
                if (cachedTraces.bb.length === 0) {
                    cachedTraces.bb = createBollingerBandTraces(window.currentStockData.dates, window.currentStockData.data);
                }
                
                // Add the Bollinger Band traces
                Plotly.addTraces(chartElement, cachedTraces.bb);
                logMessage(`Added Bollinger Bands to chart in ${(performance.now() - startTime).toFixed(2)}ms`);
                
                // Update status without recalculating trade opportunities
                document.getElementById('status').textContent = 'Bollinger Bands added to chart';
            } else {
                // Hide Bollinger Bands - use more efficient trace filtering
                const data = chartElement.data;
                if (!data) return;
                
                // Find indices of Bollinger Band traces to remove (they have names containing "BB")
                const traceIndicesToRemove = [];
                for (let i = 0; i < data.length; i++) {
                    if (data[i].name && data[i].name.includes('BB')) {
                        traceIndicesToRemove.push(i);
                    }
                }
                
                // Remove the traces if any were found
                if (traceIndicesToRemove.length > 0) {
                    Plotly.deleteTraces(chartElement, traceIndicesToRemove);
                    logMessage(`Removed Bollinger Bands from chart in ${(performance.now() - startTime).toFixed(2)}ms`);
                    
                    // Update status without recalculating trade opportunities
                    document.getElementById('status').textContent = 'Bollinger Bands removed from chart';
                }
            }
        }
    });
    
    // Performance-optimized toggle ATR button
    document.getElementById('toggleATRBtn').addEventListener('click', function() {
        // Get chart element
        const chartElement = document.getElementById('stockChart');
        if (!chartElement) return;
        
        // Toggle visibility
        showATR = !showATR;
        this.classList.toggle('active');
        
        // Update UI
        logMessage(`${showATR ? 'Showing' : 'Hiding'} ATR indicator`);
        
        if (window.currentStockData) {
            const startTime = performance.now();
            
            if (showATR) {
                // Show ATR - either use cached traces or create new ones
                if (cachedTraces.atr.length === 0) {
                    cachedTraces.atr = createATRTraces(window.currentStockData.dates, window.currentStockData.data);
                }
                
                // Update layout to include ATR subplot if it doesn't exist yet
                const hasATRPanel = chartElement.layout && chartElement.layout.yaxis5;
                if (!hasATRPanel) {
                    Plotly.relayout(chartElement, {
                        'yaxis5': {
                            title: 'ATR (14)',
                            domain: [0.27, 0.37],
                            fixedrange: true,
                            gridcolor: darkTheme ? 'rgba(80, 80, 80, 0.2)' : 'rgba(200, 200, 200, 0.2)',
                            zerolinecolor: darkTheme ? 'rgba(80, 80, 80, 0.5)' : 'rgba(200, 200, 200, 0.5)',
                            tickfont: {
                                color: darkTheme ? '#AAAAAA' : '#666666'
                            }
                        }
                    });
                }
                
                // Add the ATR traces
                Plotly.addTraces(chartElement, cachedTraces.atr);
                logMessage(`Added ATR indicator to chart in ${(performance.now() - startTime).toFixed(2)}ms`);
                
                // Update status without recalculating trade opportunities
                document.getElementById('status').textContent = 'ATR indicator added to chart';
            } else {
                // Hide ATR - use more efficient trace filtering
                const data = chartElement.data;
                if (!data) return;
                
                // Find indices of ATR traces to remove (they use yaxis5)
                const traceIndicesToRemove = [];
                for (let i = 0; i < data.length; i++) {
                    if (data[i].yaxis === 'y5') {
                        traceIndicesToRemove.push(i);
                    }
                }
                
                // Remove the traces if any were found
                if (traceIndicesToRemove.length > 0) {
                    Plotly.deleteTraces(chartElement, traceIndicesToRemove);
                    logMessage(`Removed ATR indicator from chart in ${(performance.now() - startTime).toFixed(2)}ms`);
                    
                    // Update status without recalculating trade opportunities
                    document.getElementById('status').textContent = 'ATR indicator removed from chart';
                }
            }
        }
    });
    
    // Performance-optimized toggle EMAs button
    document.getElementById('toggleEMAsBtn').addEventListener('click', function() {
        // Get chart element
        const chartElement = document.getElementById('stockChart');
        if (!chartElement) return;
        
        // Toggle visibility
        showEMAs = !showEMAs;
        this.classList.toggle('active');
        
        // Update UI
        logMessage(`${showEMAs ? 'Showing' : 'Hiding'} EMAs`);
        
        if (window.currentStockData) {
            const startTime = performance.now();
            
            if (showEMAs) {
                // Show EMAs - either use cached traces or create new ones
                if (cachedTraces.ema.length === 0) {
                    cachedTraces.ema = createEMATraces(window.currentStockData.dates, window.currentStockData.data);
                }
                
                // Add the EMA traces
                Plotly.addTraces(chartElement, cachedTraces.ema);
                logMessage(`Added EMAs to chart in ${(performance.now() - startTime).toFixed(2)}ms`);
                
                // Important: Don't recalculate trade opportunities, but update status message
                document.getElementById('status').textContent = 'EMAs added to chart';
            } else {
                // Hide EMAs - use more efficient trace filtering
                const data = chartElement.data;
                if (!data) return;
                
                // Find indices of EMA traces to remove (they have names containing "EMA")
                const traceIndicesToRemove = [];
                for (let i = 0; i < data.length; i++) {
                    if (data[i].name && data[i].name.includes('EMA')) {
                        traceIndicesToRemove.push(i);
                    }
                }
                
                // Remove the traces if any were found
                if (traceIndicesToRemove.length > 0) {
                    Plotly.deleteTraces(chartElement, traceIndicesToRemove);
                    logMessage(`Removed EMAs from chart in ${(performance.now() - startTime).toFixed(2)}ms`);
                    
                    // Important: Don't recalculate trade opportunities, but update status message
                    document.getElementById('status').textContent = 'EMAs removed from chart';
                }
            }
        }
    });
    
    // Initialize button states
    if (showChannels) {
        document.getElementById('toggleChannelsBtn').classList.add('active');
    }
    
    if (showFibLevels) {
        document.getElementById('toggleFibBtn').classList.add('active');
    }
    
    if (showRSI) {
        document.getElementById('toggleRSIBtn').classList.add('active');
    }
    
    if (showMACD) {
        document.getElementById('toggleMACDBtn').classList.add('active');
    }
    
    if (showBB) {
        document.getElementById('toggleBollingerBtn').classList.add('active');
    }
    
    if (showATR) {
        document.getElementById('toggleATRBtn').classList.add('active');
    }
    
    // Set EMAs button state based on default setting (EMAs should be disabled by default)
    if (showEMAs) {
        document.getElementById('toggleEMAsBtn').classList.add('active');
    }
    
    // Handle Enter key in symbol input
    document.getElementById('symbolInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            // Always reset zoom state when pressing Enter to analyze a stock
            lastZoomState = null;
            logMessage('Enter key pressed on symbol input, resetting zoom state');
            
            // Clear backtest inputs when changing stock
            clearBacktestResults();
            fetchStockData();
        }
    });
    
    // Handle symbol change
    document.getElementById('symbolInput').addEventListener('change', function() {
        // Clear backtest inputs when symbol is changed
        clearBacktestResults();
        
        // Reset the zoom state when changing symbols
        lastZoomState = null;
    });
    
    // Set default values based on frequency selection
    document.getElementById('frequencySelect').addEventListener('change', function() {
        const frequency = this.value;
        const daysInput = document.getElementById('daysInput');
        
        // Clear backtest inputs when changing time interval
        clearBacktestResults();
        
        // Reset the zoom state when changing frequency
        lastZoomState = null;
        
        // Adjust days based on frequency - increased for better technical indicator calculations
        switch (frequency) {
            case '30min':
                daysInput.value = 25; // Increased from 15 to 25 days
                break;
            case '60min':
                daysInput.value = 45; // Increased from 30 to 45 days
                break;
            case '240min':
                daysInput.value = 120; // Increased from 90 to 120 days
                break;
        }
        
        logMessage(`Time interval changed to ${frequency}, days adjusted to ${daysInput.value}`);
    });
    
    // Theme toggle handler
    document.getElementById('themeSelect').addEventListener('change', function() {
        // Update theme based on selection
        const newTheme = this.value === 'dark';
        
        // Only update if theme has actually changed
        if (newTheme === darkTheme) {
            return; // No change, exit early
        }
        
        // Set the new theme
        darkTheme = newTheme;
        logMessage(`Chart theme changed to ${darkTheme ? 'dark' : 'light'}`);
        
        // Performance optimization: Update theme with partial redraw instead of full recreation
        const chartElement = document.getElementById('stockChart');
        
        if (window.currentStockData && chartElement && chartElement.data) {
            // Get the current chart
            const currentChart = chartElement;
            
            // Create a new layout that only updates theme-related properties
            const newLayout = {
                paper_bgcolor: darkTheme ? 'rgba(30, 30, 35, 0.98)' : 'rgba(255, 255, 255, 0.98)',
                plot_bgcolor: darkTheme ? 'rgba(30, 30, 35, 0.98)' : 'rgba(255, 255, 255, 0.98)',
                font: {
                    color: darkTheme ? '#CCCCCC' : '#333333'
                }
            };
            
            // Update axes colors
            for (let i = 1; i <= 5; i++) {
                const axisName = i === 1 ? 'yaxis' : `yaxis${i}`;
                newLayout[axisName] = {
                    gridcolor: darkTheme ? 'rgba(80, 80, 80, 0.2)' : 'rgba(200, 200, 200, 0.2)',
                    zerolinecolor: darkTheme ? 'rgba(80, 80, 80, 0.5)' : 'rgba(200, 200, 200, 0.5)',
                    tickfont: {
                        color: darkTheme ? '#AAAAAA' : '#666666'
                    }
                };
            }
            
            newLayout.xaxis = {
                gridcolor: darkTheme ? 'rgba(80, 80, 80, 0.2)' : 'rgba(200, 200, 200, 0.2)',
                zerolinecolor: darkTheme ? 'rgba(80, 80, 80, 0.5)' : 'rgba(200, 200, 200, 0.5)',
                tickfont: {
                    color: darkTheme ? '#AAAAAA' : '#666666'
                }
            };
            
            // Update only the theme-related layout properties (much faster than full redraw)
            Plotly.relayout(chartElement, newLayout);
            
            // Set CSS variables for theme colors (for other UI elements)
            document.documentElement.style.setProperty('--theme-background', darkTheme ? '#1E1E23' : '#FFFFFF');
            document.documentElement.style.setProperty('--theme-text', darkTheme ? '#CCCCCC' : '#333333');
            document.documentElement.style.setProperty('--theme-border', darkTheme ? '#444444' : '#DDDDDD');
            
            logMessage('Theme updated using optimized partial redraw');
        } else {
            // If no chart exists yet, just update the empty chart's background
            Plotly.newPlot('stockChart', [], {
                paper_bgcolor: darkTheme ? 'rgba(30, 30, 35, 0.98)' : 'rgba(255, 255, 255, 0.98)',
                plot_bgcolor: darkTheme ? 'rgba(30, 30, 35, 0.95)' : 'rgba(248, 249, 250, 0.95)',
                annotations: [{
                    text: 'Enter a stock symbol and click "Analyze Stock" to generate a chart',
                    xref: 'paper',
                    yref: 'paper',
                    x: 0.5,
                    y: 0.5,
                    showarrow: false,
                    font: {
                        size: 20,
                        color: darkTheme ? '#CCCCCC' : '#333333'
                    }
                }]
            });
        }
    });
    
    // Create an empty chart initially with a message
    Plotly.newPlot('stockChart', [], {
        paper_bgcolor: darkTheme ? 'rgba(30, 30, 35, 0.98)' : 'rgba(255, 255, 255, 0.98)',
        plot_bgcolor: darkTheme ? 'rgba(30, 30, 35, 0.95)' : 'rgba(248, 249, 250, 0.95)',
        annotations: [{
            text: 'Enter a stock symbol and click "Analyze Stock" to generate a chart',
            xref: 'paper',
            yref: 'paper',
            x: 0.5,
            y: 0.5,
            showarrow: false,
            font: {
                size: 20,
                color: darkTheme ? '#CCCCCC' : '#333333'
            }
        }]
    });
    
    // Initialize backtest results area with an empty table
    clearBacktestResults();
});