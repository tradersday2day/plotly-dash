// Stock Analysis Web Application
// An interactive JavaScript application for technical stock analysis

const express = require('express');
const axios = require('axios');
const app = express();
const PORT = 5000;
const compression = require('express-compression');

// Import channel detection and technical indicator functions
const { 
  findChannels, 
  detectChannelChanges, 
  calculateFibonacci, 
  calculateEMAs,
  calculateRSI,
  calculateMACD,
  calculateBollingerBands,
  calculateATR
} = require('./public/js/channelDetection');

// Enable compression for all responses
app.use(compression({ level: 6 })); // Level 6 is a good balance of speed and compression

// Serve static files from the public directory with caching
app.use(express.static('public', {
  maxAge: '1h', // Cache static assets for 1 hour
  etag: true
}));
app.use(express.json());

// Tiingo API key
const TIINGO_API_KEY = "5f56a656d7af371e58786dfa305d07b463e3619a";

// Configure Express to use EJS for templating
app.set('view engine', 'ejs');

// Cache for API responses to reduce redundant API calls
const apiCache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes in milliseconds

// Home route
app.get('/', (req, res) => {
  res.render('index', {
    title: 'Stock Analysis Dashboard',
    defaultSymbol: 'AAPL',
    frequencies: [
      { value: '30min', label: '30 minutes' },
      { value: '60min', label: '1 hour' },
      { value: '240min', label: '4 hours' }
    ]
  });
});

// API endpoint to fetch stock data and perform channel analysis
app.get('/api/stock-data', async (req, res) => {
  const symbol = req.query.symbol || 'AAPL';
  const frequency = req.query.frequency || '60min';
  const days = parseInt(req.query.days) || 30;
  const detectChannels = req.query.detectChannels === 'true';
  
  try {
    // Create a cache key based on request parameters
    const cacheKey = `${symbol}-${frequency}-${days}-${detectChannels}`;
    
    // Check if response is in cache and not expired
    const cachedResponse = apiCache.get(cacheKey);
    if (cachedResponse) {
      const { timestamp, data } = cachedResponse;
      const now = Date.now();
      
      // Return cached response if still valid
      if (now - timestamp < CACHE_TTL) {
        console.log(`Using cached data for ${symbol}, ${frequency}`);
        return res.json(data);
      } else {
        // Remove expired cache entry
        apiCache.delete(cacheKey);
      }
    }
    
    // Calculate start date based on days
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    const formattedStartDate = startDate.toISOString().split('T')[0];
    
    // Log request details for debugging
    console.log(`Fetching data for ${symbol}, ${frequency}, from ${formattedStartDate}`);

    // Construct the Tiingo API URL
    const url = `https://api.tiingo.com/iex/${symbol}/prices`;
    const params = {
      startDate: formattedStartDate,
      resampleFreq: frequency,
      columns: 'open,high,low,close,volume',
      token: TIINGO_API_KEY
    };

    // Make the API request
    const response = await axios.get(url, { params });
    const stockData = response.data;

    // Process the response data
    let result = {
      symbol,
      frequency,
      days,
      data: stockData
    };

    // Detect channels if requested and data is available
    if (detectChannels && stockData.length > 0) {
      console.log('Detecting price channels...');
      
      // Adjust window size based on frequency
      let windowSize = 5; // Default
      if (frequency === '240min') windowSize = 8;
      else if (frequency === '30min') windowSize = 3;
      
      // Pre-allocate array for better performance
      const processedData = new Array(stockData.length);
      
      // Process data to ensure consistent formatting for channel detection
      // Optimize the map function for better performance
      for (let i = 0; i < stockData.length; i++) {
        const item = stockData[i];
        processedData[i] = {
          index: i,
          open: +item.open, // Using unary + operator is faster than parseFloat
          high: +item.high,
          low: +item.low,
          close: +item.close,
          volume: item.volume | 0, // Bitwise OR with 0 for integer conversion
          date: item.date
        };
      }
      
      // Find price channels
      const channels = findChannels(processedData, windowSize);
      
      // Detect transitions between channels
      const channelChanges = detectChannelChanges(channels, processedData);
      
      // Calculate Fibonacci levels
      const fibLevels = calculateFibonacci(processedData);
      
      // Perform all other calculations only if needed
      // Calculate EMAs for the data
      const dataWithEMAs = calculateEMAs(processedData);
      
      // Calculate all indicators in sequence
      const dataWithAllIndicators = calculateATR(
        calculateBollingerBands(
          calculateMACD(
            calculateRSI(dataWithEMAs, 14), 
            { fastPeriod: 12, slowPeriod: 26, signalPeriod: 9 }
          ), 
          20, 2
        ), 
        14
      );
      
      // Extract dates more efficiently
      const dates = new Array(dataWithAllIndicators.length);
      for (let i = 0; i < dataWithAllIndicators.length; i++) {
        dates[i] = new Date(dataWithAllIndicators[i].date);
      }
      
      // Add to result
      result.channels = channels;
      result.channelChanges = channelChanges;
      result.fibLevels = fibLevels;
      result.data = dataWithAllIndicators;
      result.dates = dates;
      
      console.log(`Detected ${channels.length} channels and ${channelChanges.length} transitions`);
      console.log('All technical indicators calculated successfully');
    }
    
    // Store in cache
    apiCache.set(cacheKey, {
      timestamp: Date.now(),
      data: result
    });
    
    // Set cache control headers
    res.setHeader('Cache-Control', 'private, max-age=300'); // 5 minutes
    
    // Return the data
    res.json(result);
  } catch (error) {
    console.error('Error fetching stock data:', error.message);
    
    // Return an error response
    res.status(500).json({
      error: true,
      message: error.response ? error.response.data : error.message,
      details: `Failed to fetch data for ${symbol}`
    });
  }
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running at http://0.0.0.0:${PORT}`);
});